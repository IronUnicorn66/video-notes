// src/core/model-config.js
var MODEL_REVISION = "98aa99a0a9db05ae2342309f5096248665f7cba3";
var MODEL_CACHE_NAME = "video-notes-whisper-v1";
var DEFAULT_WHISPER_MODEL_ID = "base-q5_1";
var WHISPER_MODELS = Object.freeze([
  {
    id: "base-q5_1",
    label: "Base \xB7 57 MiB",
    filename: "ggml-base-q5_1.bin",
    size: 59707625,
    sha256: "422f1ae452ade6f30a004d7e5c6a43195e4433bc370bf23fac9cc591f01a8898",
    recommended: true
  },
  {
    id: "small-q5_1",
    label: "Small \xB7 181 MiB",
    filename: "ggml-small-q5_1.bin",
    size: 190085487,
    sha256: "ae85e4a935d7a567bd102fe55afc16bb595bdb618e11b2fc7591bc08120411bb"
  },
  {
    id: "medium-q5_0",
    label: "Medium \xB7 514 MiB",
    filename: "ggml-medium-q5_0.bin",
    size: 539212467,
    sha256: "19fea4b380c3a618ec4723c3eef2eb785ffba0d0538cf43f8f235e7b3b34220f",
    experimental: true
  }
].map((model) => Object.freeze({
  ...model,
  url: `https://huggingface.co/ggerganov/whisper.cpp/resolve/${MODEL_REVISION}/${model.filename}`,
  cacheName: MODEL_CACHE_NAME
})));
function getWhisperModel(modelId) {
  const model = WHISPER_MODELS.find(({ id }) => id === modelId);
  if (!model) throw new Error(`\u672A\u77E5 Whisper \u6A21\u578B\uFF1A${modelId}`);
  return model;
}
var WHISPER_MODEL = getWhisperModel(DEFAULT_WHISPER_MODEL_ID);
var WHISPER_ORIGINS = Object.freeze([
  "https://huggingface.co/*",
  "https://cdn-lfs.hf.co/*",
  "https://*.xethub.hf.co/*"
]);

// src/core/note-format.js
function pad(value, width = 2) {
  return String(value).padStart(width, "0");
}
function timestampParts(seconds) {
  const value = Math.max(0, Math.floor(Number(seconds) || 0));
  return [Math.floor(value / 3600), Math.floor(value % 3600 / 60), value % 60];
}
function formatTimestamp(seconds, separator = ":") {
  return timestampParts(seconds).map((value) => pad(value)).join(separator);
}

// src/core/note-sort-order.js
function normalizeNoteSortOrder(value) {
  return value === "oldest" ? "oldest" : "newest";
}
function sortNotesForDisplay(notes, order) {
  const direction = normalizeNoteSortOrder(order) === "oldest" ? 1 : -1;
  return [...notes].sort((left, right) => direction * (left.createdAt - right.createdAt));
}

// src/core/note-sort-controller.js
function createNoteSortController({
  initialOrder,
  onOrderChange,
  persistOrder,
  onPersistError = () => {
  }
}) {
  let order = normalizeNoteSortOrder(initialOrder);
  let hasNewerPreference = false;
  function apply(value) {
    const nextOrder = normalizeNoteSortOrder(value);
    if (nextOrder === order) return false;
    order = nextOrder;
    onOrderChange(order);
    return true;
  }
  return {
    get order() {
      return order;
    },
    sync(value, { initial = false } = {}) {
      if (initial && hasNewerPreference) return false;
      if (!initial) hasNewerPreference = true;
      return apply(value);
    },
    async select(value) {
      hasNewerPreference = true;
      const changed = apply(value);
      try {
        await persistOrder(order);
      } catch (error) {
        onPersistError(error);
      }
      return changed;
    }
  };
}

// src/core/sidepanel-note-sort.js
function createSidepanelNoteSortBinding({
  buttons,
  storage,
  getNotes,
  renderNotes: renderNotes2,
  isEditing,
  showToast: showToast2
}) {
  let pendingRender = false;
  function renderOrder(order) {
    for (const button of buttons) {
      const active = button.dataset.noteSortOrder === order;
      button.classList.toggle("is-active", active);
      button.setAttribute("aria-pressed", String(active));
    }
  }
  function renderCurrentNotes(order) {
    renderNotes2(getNotes(), order);
  }
  const controller = createNoteSortController({
    initialOrder: "newest",
    onOrderChange(order) {
      renderOrder(order);
      if (isEditing()) {
        pendingRender = true;
        return;
      }
      renderCurrentNotes(order);
    },
    persistOrder: async (order) => storage.local.set({ noteSortOrder: order }),
    onPersistError: (error) => showToast2(error.message)
  });
  for (const button of buttons) {
    button.addEventListener("click", () => {
      void controller.select(button.dataset.noteSortOrder);
    });
  }
  return {
    get order() {
      return controller.order;
    },
    initialize(value) {
      controller.sync(value, { initial: true });
      renderOrder(controller.order);
    },
    sync(value) {
      return controller.sync(value);
    },
    finishEditing({ render = true } = {}) {
      if (!pendingRender) return false;
      pendingRender = false;
      if (render) renderCurrentNotes(controller.order);
      return true;
    }
  };
}
async function initializeSidepanel({
  storage,
  onShortcutCode,
  noteSortBinding: noteSortBinding2,
  setPanelContext,
  refresh: refresh2,
  renderWhisperStatus: renderWhisperStatus2,
  renderPermissionStatus: renderPermissionStatus2
}) {
  let shortcutCode = "AltRight";
  let noteSortOrder = "newest";
  try {
    ({ shortcutCode = "AltRight", noteSortOrder = "newest" } = await storage.local.get({
      shortcutCode,
      noteSortOrder
    }));
  } catch {
  }
  onShortcutCode(shortcutCode);
  noteSortBinding2.initialize(noteSortOrder);
  await setPanelContext();
  await Promise.all([
    refresh2(),
    renderWhisperStatus2(),
    renderPermissionStatus2()
  ]);
}

// src/core/media-permissions.js
var SCREENSHOT_ORIGINS = Object.freeze(["<all_urls>"]);

// src/core/asset-url-registry.js
function createAssetUrlRegistry({
  createObjectURL = URL.createObjectURL.bind(URL),
  revokeObjectURL = URL.revokeObjectURL.bind(URL)
} = {}) {
  const urls = /* @__PURE__ */ new Map();
  return {
    set(key, blob) {
      const previous = urls.get(key);
      if (previous) revokeObjectURL(previous);
      const url = createObjectURL(blob);
      urls.set(key, url);
      return url;
    },
    revokeAll() {
      for (const url of urls.values()) revokeObjectURL(url);
      urls.clear();
    },
    get size() {
      return urls.size;
    }
  };
}
function stopNoteMedia(container) {
  for (const audio of container.querySelectorAll("audio")) {
    audio.pause();
    audio.removeAttribute("src");
    audio.load();
  }
}
async function loadNoteAssets(note, {
  getAsset,
  registry,
  isCurrent = () => true,
  registryKeyPrefix = ""
}) {
  const result = { screenshotUrl: "", audioUrl: "", warnings: [], stale: false };
  const load = async (key, field, warning) => {
    if (!key) return { key, field, warning, blob: null };
    try {
      return { key, field, warning, blob: await getAsset(key) };
    } catch {
      return { key, field, warning, blob: null };
    }
  };
  const assets = await Promise.all([
    load(note.screenshotKey, "screenshotUrl", "\u622A\u56FE\u8D44\u4EA7\u7F3A\u5931"),
    load(note.audioKey, "audioUrl", "\u5F55\u97F3\u8D44\u4EA7\u7F3A\u5931")
  ]);
  if (!isCurrent()) {
    result.stale = true;
    return result;
  }
  for (const asset of assets) {
    if (!asset.key) continue;
    if (!asset.blob) {
      result.warnings.push(asset.warning);
      continue;
    }
    const registryKey = registryKeyPrefix ? `${registryKeyPrefix}${asset.field}` : asset.key;
    result[asset.field] = registry.set(registryKey, asset.blob);
  }
  return result;
}

// src/core/note-history.js
var NOTE_HISTORY_LIMIT = 50;
var ACTION_TYPES = /* @__PURE__ */ new Set([
  "add-note",
  "edit-body",
  "edit-subtitle",
  "delete-note",
  "clear-session"
]);
function emptyNoteHistory(sessionId) {
  return { sessionId, undo: [], redo: [], updatedAt: 0 };
}
function recordNoteAction(history, action) {
  if (!ACTION_TYPES.has(action?.type) || !Array.isArray(action.noteIds)) {
    throw new Error("\u65E0\u6548\u7684\u7B14\u8BB0\u5386\u53F2\u52A8\u4F5C");
  }
  return {
    ...history,
    undo: [...history.undo, structuredClone(action)].slice(-NOTE_HISTORY_LIMIT),
    redo: [],
    updatedAt: action.createdAt
  };
}
function undoNoteHistory(history) {
  const action = history.undo.at(-1) ?? null;
  if (action === null) {
    return { action, history };
  }
  return {
    action,
    history: {
      ...history,
      undo: history.undo.slice(0, -1),
      redo: [...history.redo, action]
    }
  };
}
function redoNoteHistory(history) {
  const action = history.redo.at(-1) ?? null;
  if (action === null) {
    return { action, history };
  }
  return {
    action,
    history: {
      ...history,
      undo: [...history.undo, action],
      redo: history.redo.slice(0, -1)
    }
  };
}
function referencedNoteIds(history) {
  return new Set([...history.undo, ...history.redo].flatMap(({ noteIds }) => noteIds));
}

// src/core/storage.js
var DATABASE_VERSION = 2;
function requestResult(request2) {
  return new Promise((resolve, reject) => {
    request2.onsuccess = () => resolve(request2.result);
    request2.onerror = () => reject(request2.error);
  });
}
function transactionDone(transaction) {
  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error);
    transaction.onabort = () => reject(transaction.error ?? new Error("IndexedDB \u4E8B\u52A1\u5DF2\u4E2D\u6B62"));
  });
}
function actionId() {
  return globalThis.crypto.randomUUID();
}
function restoreNote(note, now) {
  const { deletedAt, ...visibleNote } = note;
  return { ...visibleNote, updatedAt: now };
}
function deleteNoteAt(note, now) {
  return { ...note, deletedAt: now, updatedAt: now };
}
function historyAction(type, noteIds, now, values = {}) {
  return {
    id: actionId(),
    type,
    noteIds,
    ...values,
    createdAt: now
  };
}
var VideoNotesRepository = class {
  constructor({
    databaseName = "video-notes",
    indexedDB = globalThis.indexedDB,
    IDBKeyRange = globalThis.IDBKeyRange
  } = {}) {
    if (!indexedDB) throw new Error("\u5F53\u524D\u73AF\u5883\u4E0D\u652F\u6301 IndexedDB");
    this.databaseName = databaseName;
    this.indexedDB = indexedDB;
    this.IDBKeyRange = IDBKeyRange;
    this.db = null;
    this.dbPromise = this.open();
  }
  open() {
    const request2 = this.indexedDB.open(this.databaseName, DATABASE_VERSION);
    request2.onupgradeneeded = () => {
      const database = request2.result;
      if (!database.objectStoreNames.contains("sessions")) {
        database.createObjectStore("sessions", { keyPath: "id" });
      }
      if (!database.objectStoreNames.contains("notes")) {
        const notes = database.createObjectStore("notes", { keyPath: "id" });
        notes.createIndex("sessionId", "sessionId", { unique: false });
      }
      if (!database.objectStoreNames.contains("assets")) {
        database.createObjectStore("assets", { keyPath: "key" });
      }
      if (!database.objectStoreNames.contains("history")) {
        database.createObjectStore("history", { keyPath: "sessionId" });
      }
    };
    return requestResult(request2).then((database) => {
      this.db = database;
      return database;
    });
  }
  async read(storeName, key) {
    const database = await this.dbPromise;
    return requestResult(database.transaction(storeName).objectStore(storeName).get(key));
  }
  async write(storeName, value) {
    const database = await this.dbPromise;
    const transaction = database.transaction(storeName, "readwrite");
    transaction.objectStore(storeName).put(value);
    await transactionDone(transaction);
    return value;
  }
  async remove(storeName, key) {
    const database = await this.dbPromise;
    const transaction = database.transaction(storeName, "readwrite");
    transaction.objectStore(storeName).delete(key);
    await transactionDone(transaction);
  }
  putSession(session) {
    return this.write("sessions", session);
  }
  getSession(id) {
    return this.read("sessions", id);
  }
  putNote(note) {
    return this.write("notes", note);
  }
  getNote(id) {
    return this.read("notes", id);
  }
  async updateNote(id, updater) {
    const database = await this.dbPromise;
    return new Promise((resolve, reject) => {
      const transaction = database.transaction("notes", "readwrite");
      const store = transaction.objectStore("notes");
      const request2 = store.get(id);
      let updated;
      request2.onsuccess = () => {
        if (request2.result === void 0) {
          transaction.abort();
          reject(new Error(`\u6807\u8BB0\u4E0D\u5B58\u5728\uFF1A${id}`));
          return;
        }
        try {
          updated = updater(request2.result);
          store.put(updated);
        } catch (error) {
          transaction.abort();
          reject(error);
        }
      };
      request2.onerror = () => reject(request2.error);
      transaction.oncomplete = () => resolve(updated);
      transaction.onerror = () => reject(transaction.error);
      transaction.onabort = () => reject(transaction.error ?? new Error("\u66F4\u65B0\u6807\u8BB0\u5931\u8D25"));
    });
  }
  deleteNote(id) {
    return this.remove("notes", id);
  }
  async listNotes(sessionId) {
    const database = await this.dbPromise;
    const transaction = database.transaction("notes");
    const index = transaction.objectStore("notes").index("sessionId");
    const notes = await requestResult(index.getAll(this.IDBKeyRange.only(sessionId)));
    return notes.filter((note) => note.deletedAt === void 0).sort((left, right) => left.createdAt - right.createdAt);
  }
  async listPendingTranscriptions() {
    const database = await this.dbPromise;
    const notes = await requestResult(
      database.transaction("notes").objectStore("notes").getAll()
    );
    return notes.filter((note) => note.status === "saved" && note.deletedAt === void 0 && Boolean(note.audioKey) && ["pending", "transcribing"].includes(note.transcriptionStatus));
  }
  putAsset(key, blob) {
    return this.write("assets", {
      key,
      blob,
      mimeType: blob.type,
      createdAt: Date.now()
    });
  }
  async getAsset(key) {
    return (await this.read("assets", key))?.blob;
  }
  deleteAsset(key) {
    return this.remove("assets", key);
  }
  async mutateHistory(sessionId, now, callback) {
    const database = await this.dbPromise;
    return new Promise((resolve, reject) => {
      const transaction = database.transaction(["notes", "history", "assets"], "readwrite");
      const noteStore = transaction.objectStore("notes");
      const historyStore = transaction.objectStore("history");
      const assetStore = transaction.objectStore("assets");
      const notesRequest = noteStore.getAll();
      const historyRequest = historyStore.get(sessionId);
      let allNotes;
      let storedHistory;
      let notesLoaded = false;
      let historyLoaded = false;
      let outcome;
      let settled = false;
      const fail = (error) => {
        if (settled) return;
        settled = true;
        reject(error);
      };
      const run = () => {
        if (!notesLoaded || !historyLoaded) return;
        const notes = new Map(
          allNotes.filter((note) => note.sessionId === sessionId).map((note) => [note.id, note])
        );
        const history = storedHistory ?? emptyNoteHistory(sessionId);
        try {
          outcome = callback({ notes, history }) ?? {};
          const nextHistory = outcome.history ?? (outcome.action ? recordNoteAction(history, outcome.action) : history);
          for (const note of outcome.changedNotes ?? []) {
            noteStore.put(note);
          }
          if (outcome.action || outcome.history) {
            historyStore.put(nextHistory);
          }
          if (outcome.changed) {
            const referencedIds = referencedNoteIds(nextHistory);
            const allNotesById = new Map(allNotes.map((note) => [note.id, note]));
            for (const note of outcome.changedNotes ?? []) {
              allNotesById.set(note.id, note);
            }
            const deletedNotes = [...notes.values()].filter((note) => note.deletedAt !== void 0 && !referencedIds.has(note.id));
            const deletedNoteIds = new Set(deletedNotes.map((note) => note.id));
            const retainedAssetKeys = new Set(
              [...allNotesById.values()].filter((note) => !deletedNoteIds.has(note.id)).flatMap((note) => [note.screenshotKey, note.audioKey]).filter(Boolean)
            );
            for (const note of deletedNotes) {
              noteStore.delete(note.id);
              if (note.screenshotKey && !retainedAssetKeys.has(note.screenshotKey)) {
                assetStore.delete(note.screenshotKey);
              }
              if (note.audioKey && !retainedAssetKeys.has(note.audioKey)) {
                assetStore.delete(note.audioKey);
              }
            }
          }
        } catch (error) {
          transaction.abort();
          fail(error);
        }
      };
      notesRequest.onsuccess = () => {
        allNotes = notesRequest.result;
        notesLoaded = true;
        run();
      };
      historyRequest.onsuccess = () => {
        storedHistory = historyRequest.result;
        historyLoaded = true;
        run();
      };
      notesRequest.onerror = () => fail(notesRequest.error);
      historyRequest.onerror = () => fail(historyRequest.error);
      transaction.oncomplete = () => {
        if (!settled) {
          settled = true;
          resolve(outcome?.result);
        }
      };
      transaction.onerror = () => fail(transaction.error ?? new Error("\u7B14\u8BB0\u5386\u53F2\u66F4\u65B0\u5931\u8D25"));
      transaction.onabort = () => fail(transaction.error ?? new Error("\u7B14\u8BB0\u5386\u53F2\u66F4\u65B0\u5931\u8D25"));
    });
  }
  async commitSavedNote(id, changes, now = Date.now()) {
    const existing = await this.getNote(id);
    if (existing === void 0) throw new Error(`\u6807\u8BB0\u4E0D\u5B58\u5728\uFF1A${id}`);
    return this.mutateHistory(existing.sessionId, now, ({ notes }) => {
      const note = notes.get(id);
      if (note === void 0) throw new Error(`\u6807\u8BB0\u4E0D\u5B58\u5728\uFF1A${id}`);
      const updated = { ...note, ...changes, updatedAt: now };
      const becameSaved = note.status !== "saved" && updated.status === "saved";
      notes.set(id, updated);
      return {
        changed: true,
        changedNotes: [updated],
        action: becameSaved ? historyAction("add-note", [id], now) : void 0,
        result: updated
      };
    });
  }
  mutateNoteValue(id, field, value, type, now, incrementsUserEditVersion) {
    return this.getNote(id).then((existing) => {
      if (existing === void 0) throw new Error(`\u6807\u8BB0\u4E0D\u5B58\u5728\uFF1A${id}`);
      return this.mutateHistory(existing.sessionId, now, ({ notes }) => {
        const note = notes.get(id);
        if (note === void 0) throw new Error(`\u6807\u8BB0\u4E0D\u5B58\u5728\uFF1A${id}`);
        if (note[field] === value) return { changed: false, result: note };
        const updated = {
          ...note,
          [field]: value,
          ...incrementsUserEditVersion ? { userEditVersion: (note.userEditVersion ?? 0) + 1 } : {},
          updatedAt: now
        };
        notes.set(id, updated);
        return {
          changed: true,
          changedNotes: [updated],
          action: historyAction(type, [id], now, { before: note[field] ?? "", after: value }),
          result: updated
        };
      });
    });
  }
  editNoteBody(id, value, now = Date.now()) {
    return this.mutateNoteValue(
      id,
      "body",
      String(value ?? "").trim(),
      "edit-body",
      now,
      true
    );
  }
  editNoteSubtitle(id, value, now = Date.now()) {
    return this.mutateNoteValue(
      id,
      "subtitleContext",
      String(value ?? "").trim(),
      "edit-subtitle",
      now,
      false
    );
  }
  deleteSavedNote(id, now = Date.now()) {
    return this.getNote(id).then((existing) => {
      if (existing === void 0) throw new Error(`\u6807\u8BB0\u4E0D\u5B58\u5728\uFF1A${id}`);
      return this.mutateHistory(existing.sessionId, now, ({ notes }) => {
        const note = notes.get(id);
        if (note === void 0 || note.deletedAt !== void 0) {
          throw new Error("\u7B14\u8BB0\u5386\u53F2\u52A8\u4F5C\u5DF2\u8FC7\u671F");
        }
        const updated = deleteNoteAt(note, now);
        notes.set(id, updated);
        return {
          changed: true,
          changedNotes: [updated],
          action: historyAction("delete-note", [id], now),
          result: updated
        };
      });
    });
  }
  clearSessionNotes(sessionId, now = Date.now()) {
    return this.mutateHistory(sessionId, now, ({ notes }) => {
      const visibleNotes = [...notes.values()].filter((note) => note.deletedAt === void 0);
      if (visibleNotes.length === 0) return { changed: false, result: [] };
      const changedNotes = visibleNotes.map((note) => {
        const updated = deleteNoteAt(note, now);
        notes.set(note.id, updated);
        return updated;
      });
      return {
        changed: true,
        changedNotes,
        action: historyAction("clear-session", visibleNotes.map((note) => note.id), now),
        result: changedNotes
      };
    });
  }
  applyHistoryAction(notes, action, undo, now) {
    const actionNotes = action.noteIds.map((id) => notes.get(id));
    if (actionNotes.some((note) => note === void 0)) {
      throw new Error("\u7B14\u8BB0\u5386\u53F2\u52A8\u4F5C\u5DF2\u8FC7\u671F");
    }
    const isEdit = action.type === "edit-body" || action.type === "edit-subtitle";
    const shouldDelete = action.type === "add-note" === undo;
    if (isEdit) {
      const field = action.type === "edit-body" ? "body" : "subtitleContext";
      const expected = undo ? action.after : action.before;
      if (actionNotes.some((note) => note.deletedAt !== void 0 || note[field] !== expected)) {
        throw new Error("\u7B14\u8BB0\u5386\u53F2\u52A8\u4F5C\u5DF2\u8FC7\u671F");
      }
      return actionNotes.map((note) => {
        const updated = {
          ...note,
          [field]: undo ? action.before : action.after,
          ...action.type === "edit-body" ? { userEditVersion: (note.userEditVersion ?? 0) + 1 } : {},
          updatedAt: now
        };
        notes.set(updated.id, updated);
        return updated;
      });
    }
    if (actionNotes.some((note) => note.deletedAt !== void 0 !== !shouldDelete)) {
      throw new Error("\u7B14\u8BB0\u5386\u53F2\u52A8\u4F5C\u5DF2\u8FC7\u671F");
    }
    return actionNotes.map((note) => {
      const updated = shouldDelete ? deleteNoteAt(note, now) : restoreNote(note, now);
      notes.set(updated.id, updated);
      return updated;
    });
  }
  changeHistoryStack(sessionId, now, changeHistory) {
    return this.mutateHistory(sessionId, now, ({ notes, history }) => {
      const { action, history: nextHistory } = changeHistory(history);
      if (action === null) return { changed: false, result: null };
      const changedNotes = this.applyHistoryAction(notes, action, changeHistory === undoNoteHistory, now);
      return {
        changed: true,
        changedNotes,
        history: { ...nextHistory, updatedAt: now },
        result: action
      };
    });
  }
  undoNoteAction(sessionId, now = Date.now()) {
    return this.changeHistoryStack(sessionId, now, undoNoteHistory);
  }
  redoNoteAction(sessionId, now = Date.now()) {
    return this.changeHistoryStack(sessionId, now, redoNoteHistory);
  }
  async getNoteHistoryState(sessionId) {
    const history = await this.read("history", sessionId);
    return {
      canUndo: Boolean(history?.undo.length),
      canRedo: Boolean(history?.redo.length)
    };
  }
  close() {
    if (this.db) this.db.close();
    else void this.dbPromise.then((database) => database.close());
  }
  async destroy() {
    const database = await this.dbPromise;
    database.close();
    await requestResult(this.indexedDB.deleteDatabase(this.databaseName));
  }
};

// src/core/sidepanel-scope.js
function isSidePanelRefreshMessage(message) {
  return [
    "ACTIVE_CONTEXT_CHANGED",
    "TAB_LOAD_COMPLETE",
    "NOTE_TRANSCRIBED",
    "VOICE_STATE_CHANGED"
  ].includes(message?.type);
}
function createSidePanelRefreshController(refresh2, {
  onContextEvent = () => {
  },
  shouldRefresh = () => true,
  shouldDeferRefresh = () => false
} = {}) {
  let tabId = null;
  let deferredMessage = null;
  function refreshOrDefer(message) {
    onContextEvent(message);
    if (!shouldRefresh(message)) return false;
    if (shouldDeferRefresh(message)) {
      deferredMessage = message;
      return false;
    }
    refresh2(message);
    return true;
  }
  return {
    get tabId() {
      return tabId;
    },
    setTabId(value) {
      tabId = Number.isInteger(value) ? value : null;
    },
    handleContextChanged(message) {
      if (message?.type === "ACTIVE_CONTEXT_CHANGED" && Number.isInteger(message.tabId)) {
        tabId = message.tabId;
      }
      if (!Number.isInteger(tabId) || message?.tabId !== tabId) return false;
      refreshOrDefer(message);
      return true;
    },
    handleVisibilityChange(visible) {
      if (!visible || !Number.isInteger(tabId)) return false;
      refreshOrDefer({ type: "SIDE_PANEL_VISIBLE", tabId });
      return true;
    },
    requestRefresh(message) {
      return refreshOrDefer(message);
    },
    flushDeferredRefresh() {
      if (!deferredMessage) return false;
      const message = deferredMessage;
      deferredMessage = null;
      refresh2(message);
      return true;
    }
  };
}

// src/core/inline-edit-state.js
function inlineEditResolution({ canceled, saveSucceeded, text }) {
  const resolved = canceled === true || saveSucceeded === true;
  return {
    retryText: resolved ? null : String(text ?? ""),
    allowDeferredRefresh: resolved
  };
}
function inlineEditStartingText(retryText, initialText) {
  return String(retryText === void 0 ? initialText ?? "" : retryText ?? "");
}
function shouldDeferInlineEditRefresh({
  editing = false,
  pendingSaveCount = 0,
  retryCount = 0
}) {
  return editing === true || pendingSaveCount > 0 || retryCount > 0;
}

// src/core/sidepanel-interaction.js
function createSidePanelInlineEditController({
  onEditStarted = () => {
  },
  onError = () => {
  },
  flushDeferredRefresh = () => false
} = {}) {
  const editing = /* @__PURE__ */ new Set();
  const pendingSaves = /* @__PURE__ */ new Set();
  const retries = /* @__PURE__ */ new Map();
  const generations = /* @__PURE__ */ new WeakMap();
  function isBlocked() {
    return shouldDeferInlineEditRefresh({
      editing: editing.size > 0,
      pendingSaveCount: pendingSaves.size,
      retryCount: retries.size
    });
  }
  function flushIfResolved() {
    if (!isBlocked()) flushDeferredRefresh();
  }
  function begin({
    noteId,
    button,
    content,
    initialText,
    restore,
    save,
    applySaved
  }) {
    if (button.disabled || editing.has(content) || pendingSaves.has(content)) return null;
    const generation = (generations.get(content) ?? 0) + 1;
    generations.set(content, generation);
    const isCurrent = () => generations.get(content) === generation;
    let canceled = false;
    let finished = false;
    let resolveCompletion;
    const completion = new Promise((resolve) => {
      resolveCompletion = resolve;
    });
    editing.add(content);
    button.disabled = true;
    content.textContent = inlineEditStartingText(retries.get(content), initialText);
    content.contentEditable = "true";
    content.classList.remove("is-empty");
    content.classList.add("is-editing");
    content.focus();
    onEditStarted({ noteId, content });
    let keyHandler;
    const finish = async () => {
      if (finished) return;
      finished = true;
      const submittedText = String(content.textContent ?? "");
      let saveSucceeded = false;
      content.removeEventListener("keydown", keyHandler);
      content.contentEditable = "false";
      content.classList.remove("is-editing");
      editing.delete(content);
      if (canceled) {
        if (isCurrent()) {
          retries.delete(content);
          restore();
          button.disabled = false;
        }
        flushIfResolved();
        resolveCompletion({ canceled, saveSucceeded, submittedText });
        return;
      }
      pendingSaves.add(content);
      try {
        const response = await save(submittedText);
        if (isCurrent()) {
          applySaved(response, submittedText);
          retries.delete(content);
          saveSucceeded = true;
        }
      } catch (error) {
        if (isCurrent()) {
          content.textContent = submittedText;
          retries.set(content, submittedText);
          onError(error);
        }
      } finally {
        pendingSaves.delete(content);
        if (isCurrent()) button.disabled = false;
        const resolution = inlineEditResolution({
          canceled,
          saveSucceeded,
          text: submittedText
        });
        if (isCurrent() && resolution.retryText !== null) {
          retries.set(content, resolution.retryText);
        }
        if (resolution.allowDeferredRefresh) flushIfResolved();
        resolveCompletion({ canceled, saveSucceeded, submittedText });
      }
    };
    content.addEventListener("blur", () => void finish(), { once: true });
    keyHandler = (event) => {
      if (event.isComposing) return;
      if (event.key === "Escape") {
        canceled = true;
        content.blur();
      } else if (event.key === "Enter" && (event.metaKey || event.ctrlKey)) {
        event.preventDefault();
        content.blur();
      }
    };
    content.addEventListener("keydown", keyHandler);
    return { completion };
  }
  function bind({ getInitialText, ...options }) {
    const clickHandler = () => begin({
      ...options,
      initialText: getInitialText()
    });
    options.button.addEventListener("click", clickHandler);
    return () => options.button.removeEventListener("click", clickHandler);
  }
  return {
    get blocked() {
      return isBlocked();
    },
    get pendingSaveCount() {
      return pendingSaves.size;
    },
    get retryCount() {
      return retries.size;
    },
    begin,
    bind
  };
}
function createSidePanelRefreshRunner({
  load,
  apply,
  applyError,
  isBlocked = () => false,
  defer = () => {
  }
}) {
  let generation = 0;
  let pendingCount = 0;
  let appliedGeneration = 0;
  const appliedWaiters = /* @__PURE__ */ new Set();
  function markApplied() {
    appliedGeneration += 1;
    for (const resolve of appliedWaiters) {
      resolve(true);
    }
    appliedWaiters.clear();
  }
  function waitForApplied(generationToWaitFor) {
    if (appliedGeneration !== generationToWaitFor) {
      return Promise.resolve(true);
    }
    return new Promise((resolve) => {
      appliedWaiters.add(resolve);
    });
  }
  async function run() {
    const currentGeneration = ++generation;
    pendingCount += 1;
    try {
      const value = await load();
      if (currentGeneration !== generation) return false;
      if (isBlocked()) {
        defer();
        return false;
      }
      apply(value);
      markApplied();
      return true;
    } catch (error) {
      if (currentGeneration !== generation) return false;
      if (isBlocked()) {
        defer();
        return false;
      }
      applyError(error);
      markApplied();
      return true;
    } finally {
      pendingCount -= 1;
    }
  }
  function invalidateForEdit() {
    const hadPendingRefresh = pendingCount > 0;
    generation += 1;
    if (hadPendingRefresh) defer();
    return hadPendingRefresh;
  }
  async function runUntilApplied() {
    while (true) {
      const currentAppliedGeneration = appliedGeneration;
      if (await run()) return true;
      if (isBlocked()) {
        return waitForApplied(currentAppliedGeneration);
      }
    }
  }
  return {
    get pendingCount() {
      return pendingCount;
    },
    invalidateForEdit,
    run,
    runUntilApplied
  };
}

// src/core/subtitle-capture.js
var SUBTITLE_WINDOW_OPTIONS = Object.freeze([5, 10, 20, 30]);
function normalizeSubtitleSettings(values = {}) {
  const windowSeconds = Number.isInteger(values.subtitleWindowSeconds) && SUBTITLE_WINDOW_OPTIONS.includes(values.subtitleWindowSeconds) ? values.subtitleWindowSeconds : 20;
  return {
    enabled: typeof values.subtitleEnabled === "boolean" ? values.subtitleEnabled : true,
    windowSeconds
  };
}

// src/core/subtitle-view.js
function subtitleBlockState(note, enabled) {
  const text = String(note?.subtitleContext ?? "").trim();
  return {
    visible: enabled === true,
    empty: text.length === 0,
    text
  };
}

// src/core/note-history-controls.js
function historyControlState({
  noteCount,
  canUndo: canUndo2,
  canRedo: canRedo2,
  blocked,
  pending
}) {
  const unavailable = Boolean(blocked || pending);
  return {
    deleteDisabled: unavailable || noteCount <= 0,
    clearDisabled: unavailable || noteCount <= 0,
    undoDisabled: unavailable || !canUndo2,
    redoDisabled: unavailable || !canRedo2
  };
}
function historyShortcut(event) {
  if (event.isComposing || isEditableTarget(event.target) || isInsideOpenDialog(event.target) || event.key.toLowerCase() !== "z" || event.altKey || event.metaKey === event.ctrlKey) {
    return null;
  }
  return event.shiftKey ? "redo" : "undo";
}
function createHistoryConfirmationController({ getContext, isBlocked, run }) {
  let pending = null;
  function isCurrent(action) {
    if (!action || isBlocked()) return false;
    const context = getContext();
    return Boolean(
      context && context.token === action.token && context.sessionId === action.sessionId && context.tabId === action.tabId
    );
  }
  function takePending() {
    const action = pending;
    pending = null;
    return action;
  }
  function revalidate() {
    if (isCurrent(pending)) return true;
    pending = null;
    return false;
  }
  return {
    get pending() {
      return pending !== null;
    },
    open({ operation, noteId }) {
      if (pending || isBlocked()) return null;
      const context = getContext();
      if (!context || !Number.isInteger(context.tabId) || !context.sessionId) return null;
      pending = {
        operation,
        ...noteId === void 0 ? {} : { noteId },
        token: context.token,
        sessionId: context.sessionId,
        tabId: context.tabId
      };
      return { ...pending };
    },
    cancel() {
      return takePending() !== null;
    },
    revalidate,
    async confirm() {
      if (!revalidate()) return false;
      const action = takePending();
      await run(action);
      return true;
    }
  };
}
function createHistoryOperationController({ request: request2, refresh: refresh2, showError }) {
  let pending = false;
  return {
    get pending() {
      return pending;
    },
    async run(operation) {
      if (pending) return false;
      pending = true;
      try {
        await request2(operation);
        await refresh2();
        return true;
      } catch (error) {
        showError(error);
        return false;
      } finally {
        pending = false;
      }
    }
  };
}
function isEditableTarget(target) {
  return target?.isContentEditable || ["INPUT", "TEXTAREA", "SELECT"].includes(target?.tagName);
}
function isInsideOpenDialog(target) {
  if (target?.closest?.("dialog[open]")) return true;
  for (let current = target; current; current = current.parentElement) {
    if (current.tagName === "DIALOG" && current.open) return true;
  }
  return false;
}

// src/sidepanel.js
var elements = {
  videoTitle: document.querySelector("#video-title"),
  videoUrl: document.querySelector("#video-url"),
  input: document.querySelector("#note-input"),
  markerTime: document.querySelector("#marker-time"),
  voiceButton: document.querySelector("#voice-button"),
  voiceLabel: document.querySelector("#voice-button-label"),
  recordingStatus: document.querySelector("#recording-status"),
  recordingTimer: document.querySelector("#recording-timer"),
  noteList: document.querySelector("#note-list"),
  emptyNotes: document.querySelector("#empty-notes"),
  noteSortButtons: document.querySelectorAll("[data-note-sort-order]"),
  undoButton: document.querySelector("#undo-button"),
  redoButton: document.querySelector("#redo-button"),
  clearButton: document.querySelector("#clear-button"),
  exportButton: document.querySelector("#export-button"),
  whisperDetail: document.querySelector("#whisper-detail"),
  whisperModelSelect: document.querySelector("#whisper-model-select"),
  whisperModelAction: document.querySelector("#whisper-model-action"),
  whisperModelWarning: document.querySelector("#whisper-model-warning"),
  settings: document.querySelector("#permission-settings"),
  screenshotPermissionButton: document.querySelector("#screenshot-permission-button"),
  screenshotPermissionDetail: document.querySelector("#screenshot-permission-detail"),
  microphonePermissionButton: document.querySelector("#microphone-permission-button"),
  microphonePermissionDetail: document.querySelector("#microphone-permission-detail"),
  subtitleEnabled: document.querySelector("#subtitle-enabled"),
  subtitleWindowSeconds: document.querySelector("#subtitle-window-seconds"),
  keyButton: document.querySelector("#key-button"),
  toast: document.querySelector("#toast"),
  screenshotDialog: document.querySelector("#screenshot-dialog"),
  screenshotDialogClose: document.querySelector("#screenshot-dialog-close"),
  screenshotDialogImage: document.querySelector("#screenshot-dialog-image"),
  historyConfirmDialog: document.querySelector("#history-confirm-dialog"),
  historyConfirmTitle: document.querySelector("#history-confirm-title"),
  historyConfirmDescription: document.querySelector("#history-confirm-description")
};
var repository = new VideoNotesRepository();
var assetUrls = createAssetUrlRegistry();
var activeContext = null;
var currentDraft = null;
var draftPromise = null;
var typedDraftSaving = false;
var isComposing = false;
var commitAfterComposition = false;
var recording = false;
var voiceStarting = false;
var voiceStopping = false;
var pendingVoiceStopReason = null;
var recordingStartedAt = 0;
var recordingInterval = null;
var recordingTimeout = null;
var toastTimeout = null;
var refreshAfterEdit = false;
var inlineEditController = null;
var refreshRunner = null;
var microphoneReady = false;
var microphonePermissionStatus = null;
var pendingWhisperModelId = null;
var whisperStatus = null;
var renderGeneration = 0;
var currentNotes = [];
var canUndo = false;
var canRedo = false;
var historyContextToken = 0;
var activeContextTabId = null;
var historyConfirmationController = null;
var historyOperationController = null;
var subtitleSettings = normalizeSubtitleSettings();
var noteSortBinding = createSidepanelNoteSortBinding({
  buttons: elements.noteSortButtons,
  storage: chrome.storage,
  getNotes: () => currentNotes,
  renderNotes,
  isEditing: () => Boolean(inlineEditController?.blocked),
  showToast
});
var sidePanelRefresh = createSidePanelRefreshController(() => {
  void refreshNow();
}, {
  onContextEvent(message) {
    if (["ACTIVE_CONTEXT_CHANGED", "TAB_LOAD_COMPLETE"].includes(message.type)) {
      historyContextToken += 1;
      closeStaleHistoryConfirmation();
    }
    if (message.type === "VOICE_STATE_CHANGED") setRecordingUi(message.recording);
  },
  shouldRefresh(message) {
    return message.type !== "VOICE_STATE_CHANGED" || message.recording === false;
  },
  shouldDeferRefresh(message) {
    if (!inlineEditController?.blocked) return false;
    refreshAfterEdit = true;
    return true;
  }
});
function showToast(message) {
  elements.toast.textContent = message;
  elements.toast.hidden = false;
  clearTimeout(toastTimeout);
  toastTimeout = setTimeout(() => {
    elements.toast.hidden = true;
  }, 3600);
}
function syncSubtitleSettingsControls() {
  elements.subtitleEnabled.checked = subtitleSettings.enabled;
  elements.subtitleWindowSeconds.value = String(subtitleSettings.windowSeconds);
  elements.subtitleWindowSeconds.disabled = !subtitleSettings.enabled;
}
inlineEditController = createSidePanelInlineEditController({
  onEditStarted() {
    refreshRunner?.invalidateForEdit();
    syncHistoryControls();
  },
  onError(error) {
    showToast(error.message);
    syncHistoryControls();
  },
  flushDeferredRefresh() {
    syncHistoryControls();
    if (!refreshAfterEdit) {
      noteSortBinding.finishEditing();
      return false;
    }
    refreshAfterEdit = false;
    noteSortBinding.finishEditing({ render: false });
    return sidePanelRefresh.flushDeferredRefresh();
  }
});
historyOperationController = createHistoryOperationController({
  request,
  refresh: () => refreshRunner.runUntilApplied(),
  showError(error) {
    showToast(error.message);
  }
});
historyConfirmationController = createHistoryConfirmationController({
  getContext() {
    if (!activeContext) return null;
    return {
      token: historyContextToken,
      sessionId: activeContext.sessionId,
      tabId: sidePanelRefresh.tabId
    };
  },
  isBlocked: historyInteractionBlocked,
  run: runConfirmedHistoryAction
});
function savedNoteCount() {
  return currentNotes.filter((note) => note.status === "saved").length;
}
function historyInteractionBlocked() {
  return Boolean(
    currentDraft || draftPromise || recording || voiceStarting || inlineEditController.blocked || typedDraftSaving || voiceStopping || historyOperationController?.pending
  );
}
function currentHistoryControlState() {
  return historyControlState({
    noteCount: savedNoteCount(),
    canUndo,
    canRedo,
    blocked: historyInteractionBlocked(),
    pending: historyOperationController.pending
  });
}
function syncHistoryControls() {
  closeStaleHistoryConfirmation();
  const controls = currentHistoryControlState();
  elements.clearButton.disabled = controls.clearDisabled;
  elements.undoButton.disabled = controls.undoDisabled;
  elements.redoButton.disabled = controls.redoDisabled;
  for (const deleteButton of elements.noteList.querySelectorAll(".note-delete-button")) {
    deleteButton.disabled = controls.deleteDisabled;
  }
}
function closeStaleHistoryConfirmation() {
  if (!historyConfirmationController?.pending) return;
  if (historyConfirmationController.revalidate()) return;
  if (elements.historyConfirmDialog.open) elements.historyConfirmDialog.close("cancel");
}
function canRunHistoryAction(operation) {
  const controls = currentHistoryControlState();
  if (!activeContext || !Number.isInteger(sidePanelRefresh.tabId) || activeContextTabId !== sidePanelRefresh.tabId) return false;
  if (operation === "undo") return !controls.undoDisabled;
  if (operation === "redo") return !controls.redoDisabled;
  if (operation === "clear" || operation === "delete") return !controls.clearDisabled;
  return false;
}
async function runHistoryOperation(message) {
  const operation = historyOperationController.run(message);
  syncHistoryControls();
  const succeeded = await operation;
  syncHistoryControls();
  return succeeded;
}
function runConfirmedHistoryAction(action) {
  if (action.operation === "delete") {
    return runHistoryOperation({
      type: "DELETE_NOTE",
      noteId: action.noteId,
      sessionId: action.sessionId,
      tabId: action.tabId
    });
  }
  return runHistoryOperation({
    type: "CLEAR_SESSION_NOTES",
    sessionId: action.sessionId,
    tabId: action.tabId
  });
}
function confirmHistoryAction({ title, description }, action) {
  if (elements.historyConfirmDialog.open) return;
  if (!historyConfirmationController.open(action)) return;
  elements.historyConfirmTitle.textContent = title;
  elements.historyConfirmDescription.textContent = description;
  elements.historyConfirmDialog.returnValue = "";
  elements.historyConfirmDialog.showModal();
}
function whisperModelLabel(modelId) {
  return whisperStatus?.models.find((model) => model.id === modelId)?.label ?? "\u5F53\u524D\u6A21\u578B";
}
function retranscriptionUnavailableReason(note) {
  if (!note.audioKey) return "\u539F\u59CB\u5F55\u97F3\u4E0D\u53EF\u7528";
  if (!whisperStatus) return "\u6B63\u5728\u8BFB\u53D6\u6A21\u578B\u72B6\u6001";
  const selectedModelId = whisperStatus.selectedModelId;
  if (!whisperStatus.cachedModelIds.includes(selectedModelId)) return "\u5F53\u524D\u6A21\u578B\u5C1A\u672A\u7F13\u5B58";
  if (["downloading", "recording", "transcribing"].includes(whisperStatus.whisperState)) {
    return "\u5F53\u524D\u8BED\u97F3\u4EFB\u52A1\u8FDB\u884C\u4E2D";
  }
  return "";
}
function formatTranscriptionTime(createdAt) {
  return new Date(createdAt).toLocaleString("zh-CN", {
    month: "numeric",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  });
}
async function request(message) {
  const payload = message.type === "GET_ACTIVE_STATE" && Number.isInteger(sidePanelRefresh.tabId) ? { ...message, tabId: sidePanelRefresh.tabId } : message;
  const response = await chrome.runtime.sendMessage(payload);
  if (!response?.ok) throw new Error(response?.error ?? "\u64CD\u4F5C\u5931\u8D25");
  return response;
}
async function readMicrophonePermission() {
  const { microphoneReady: savedReady = false } = await chrome.storage.local.get({
    microphoneReady: false
  });
  try {
    const status = await navigator.permissions.query({ name: "microphone" });
    if (microphonePermissionStatus !== status) {
      if (microphonePermissionStatus) microphonePermissionStatus.onchange = null;
      microphonePermissionStatus = status;
      microphonePermissionStatus.onchange = () => {
        microphoneReady = microphonePermissionStatus.state === "granted";
        void chrome.storage.local.set({ microphoneReady }).then(() => renderPermissionStatus());
      };
    }
    const ready = status.state === "granted";
    if (ready !== savedReady) await chrome.storage.local.set({ microphoneReady: ready });
    return { ready, state: status.state };
  } catch {
    return { ready: savedReady, state: savedReady ? "granted" : "prompt" };
  }
}
async function renderPermissionStatus({ expandIfNeeded = false } = {}) {
  const [screenshotGranted, microphone] = await Promise.all([
    chrome.permissions.contains({ origins: SCREENSHOT_ORIGINS }),
    readMicrophonePermission()
  ]);
  microphoneReady = microphone.ready;
  elements.screenshotPermissionDetail.textContent = screenshotGranted ? "\u5DF2\u6388\u6743\u3002\u53EA\u5728 YouTube \u548C\u54D4\u54E9\u54D4\u54E9\u6807\u8BB0\u65F6\u622A\u53D6\u53EF\u89C1\u64AD\u653E\u5668\u3002" : "Edge \u622A\u56FE\u63A5\u53E3\u9700\u8981\u4E00\u6B21\u989D\u5916\u6388\u6743\uFF1B\u63D2\u4EF6\u4ECD\u53EA\u5728\u652F\u6301\u7684\u89C6\u9891\u9875\u8FD0\u884C\u3002";
  elements.screenshotPermissionButton.textContent = screenshotGranted ? "\u5DF2\u542F\u7528" : "\u542F\u7528";
  elements.screenshotPermissionButton.disabled = screenshotGranted;
  elements.microphonePermissionDetail.textContent = microphone.ready ? "\u5DF2\u6388\u6743\u3002\u53EA\u5728\u6309\u4F4F\u8BF4\u8BDD\u671F\u95F4\u5F55\u97F3\u3002" : microphone.state === "denied" ? "\u6743\u9650\u5DF2\u88AB\u62D2\u7EDD\uFF0C\u8BF7\u6253\u5F00\u6388\u6743\u9875\uFF0C\u5728 Edge \u5730\u5740\u680F\u6743\u9650\u8BBE\u7F6E\u4E2D\u5141\u8BB8\u540E\u91CD\u8BD5\u3002" : "\u70B9\u51FB\u6388\u6743\u4F1A\u6253\u5F00\u72EC\u7ACB\u9875\u9762\uFF0C\u8BF7\u5728\u90A3\u91CC\u786E\u8BA4 Edge \u7684\u9EA6\u514B\u98CE\u6743\u9650\u3002";
  elements.microphonePermissionButton.textContent = microphone.ready ? "\u5DF2\u6388\u6743" : "\u6388\u6743";
  elements.microphonePermissionButton.disabled = microphone.ready;
  if (expandIfNeeded && (!screenshotGranted || !microphone.ready)) {
    elements.settings.open = true;
  }
}
async function openMicrophonePermissionPage() {
  await request({ type: "OPEN_MICROPHONE_PERMISSION_PAGE" });
}
function autoGrow() {
  elements.input.style.height = "auto";
  elements.input.style.height = `${Math.min(elements.input.scrollHeight, 260)}px`;
}
function closeScreenshotDialog() {
  if (elements.screenshotDialog.open) elements.screenshotDialog.close();
  elements.screenshotDialogImage.removeAttribute("src");
}
function appendAssetWarning(container, message) {
  const warning = document.createElement("span");
  warning.className = "note-asset-warning";
  warning.textContent = message;
  container.append(warning);
}
async function renderNoteAssets(note, container, generation) {
  try {
    const assets = await loadNoteAssets(note, {
      getAsset: (key) => repository.getAsset(key),
      registry: assetUrls,
      isCurrent: () => generation === renderGeneration,
      registryKeyPrefix: `note:${note.id}:`
    });
    if (assets.stale) return;
    if (note.screenshotKey) {
      if (!assets.screenshotUrl) {
        appendAssetWarning(container, "\u622A\u56FE\u6587\u4EF6\u7F3A\u5931");
      } else {
        const button = document.createElement("button");
        button.className = "note-screenshot-button";
        button.type = "button";
        button.setAttribute("aria-label", "\u653E\u5927\u6807\u8BB0\u622A\u56FE");
        const image = document.createElement("img");
        image.className = "note-screenshot";
        image.loading = "lazy";
        image.alt = "\u6807\u8BB0\u65F6\u7684\u64AD\u653E\u5668\u622A\u56FE";
        image.src = assets.screenshotUrl;
        button.append(image);
        button.addEventListener("click", () => {
          elements.screenshotDialogImage.src = image.src;
          if (!elements.screenshotDialog.open) elements.screenshotDialog.showModal();
        });
        container.append(button);
      }
    }
    if (note.audioKey) {
      if (!assets.audioUrl) {
        appendAssetWarning(container, "\u5F55\u97F3\u6587\u4EF6\u7F3A\u5931");
      } else {
        const player = document.createElement("audio");
        player.className = "note-audio";
        player.controls = true;
        player.preload = "metadata";
        player.src = assets.audioUrl;
        container.append(player);
      }
    }
  } catch {
    if (generation !== renderGeneration) return;
    if (note.screenshotKey) {
      appendAssetWarning(container, "\u622A\u56FE\u6587\u4EF6\u7F3A\u5931");
    }
    if (note.audioKey) {
      appendAssetWarning(container, "\u5F55\u97F3\u6587\u4EF6\u7F3A\u5931");
    }
  }
}
function renderNotes(notes, order = noteSortBinding.order) {
  currentNotes = notes;
  const generation = ++renderGeneration;
  closeScreenshotDialog();
  stopNoteMedia(elements.noteList);
  assetUrls.revokeAll();
  const saved = sortNotesForDisplay(
    currentNotes.filter((note) => note.status === "saved"),
    order
  );
  elements.noteList.replaceChildren();
  elements.emptyNotes.hidden = saved.length > 0;
  elements.exportButton.disabled = saved.length === 0;
  for (const note of saved) {
    const item = document.createElement("li");
    item.className = "note-card";
    const header = document.createElement("div");
    header.className = "note-card-header";
    const time = document.createElement("a");
    time.className = "note-time";
    time.href = note.jumpUrl;
    time.target = "_blank";
    time.textContent = formatTimestamp(note.seconds);
    const kind = document.createElement("span");
    kind.className = "note-kind";
    kind.textContent = note.inputType === "voice" ? "\u8BED\u97F3" : "\u6587\u5B57";
    const edit = document.createElement("button");
    edit.className = "note-edit-button";
    edit.type = "button";
    edit.textContent = "\u7F16\u8F91";
    const deleteButton = document.createElement("button");
    deleteButton.className = "note-delete-button";
    deleteButton.type = "button";
    deleteButton.textContent = "\u5220\u9664";
    deleteButton.addEventListener("click", () => {
      if (!canRunHistoryAction("delete")) return;
      confirmHistoryAction({
        title: "\u5220\u9664\u8FD9\u6761\u6807\u8BB0\uFF1F",
        description: `\u5C06\u5220\u9664 ${formatTimestamp(note.seconds)} \u7684\u6807\u8BB0\u3002`
      }, { operation: "delete", noteId: note.id });
    });
    const actions = document.createElement("span");
    actions.className = "note-card-actions";
    actions.append(kind, edit, deleteButton);
    header.append(time, actions);
    item.append(header);
    const body = document.createElement("p");
    body.className = "note-body";
    body.textContent = note.body || (note.inputType === "voice" ? "\u5DF2\u4FDD\u7559\u539F\u59CB\u5F55\u97F3" : "\u7A7A\u6807\u8BB0");
    item.append(body);
    const assets = document.createElement("div");
    assets.className = "note-assets";
    item.append(assets);
    void renderNoteAssets(note, assets, generation);
    inlineEditController.bind({
      noteId: note.id,
      button: edit,
      content: body,
      getInitialText: () => note.body ?? "",
      restore() {
        body.textContent = note.body || (note.inputType === "voice" ? "\u5DF2\u4FDD\u7559\u539F\u59CB\u5F55\u97F3" : "\u7A7A\u6807\u8BB0");
      },
      save(text) {
        return request({
          type: "UPDATE_NOTE_BODY",
          noteId: note.id,
          body: text
        });
      },
      applySaved(response) {
        note.body = response.note.body;
        body.textContent = note.body || (note.inputType === "voice" ? "\u5DF2\u4FDD\u7559\u539F\u59CB\u5F55\u97F3" : "\u7A7A\u6807\u8BB0");
      }
    });
    const subtitleState = subtitleBlockState(note, subtitleSettings.enabled);
    if (subtitleState.visible) {
      const subtitleBlock = document.createElement("section");
      subtitleBlock.className = "note-subtitle";
      const subtitleHeader = document.createElement("div");
      subtitleHeader.className = "note-subtitle-header";
      const subtitleTitle = document.createElement("strong");
      subtitleTitle.textContent = "\u524D\u7F6E\u5B57\u5E55";
      const subtitleEdit = document.createElement("button");
      subtitleEdit.className = "note-edit-button";
      subtitleEdit.type = "button";
      subtitleEdit.textContent = "\u7F16\u8F91\u5B57\u5E55";
      const subtitle = document.createElement("p");
      subtitle.className = "note-subtitle-text";
      const renderSubtitle = () => {
        const state = subtitleBlockState(note, true);
        subtitle.textContent = state.empty ? "\u672A\u8BFB\u53D6\u5230\u5B57\u5E55\uFF0C\u8BF7\u786E\u8BA4\u64AD\u653E\u5668\u5DF2\u5F00\u542F\u5B57\u5E55" : state.text;
        subtitle.classList.toggle("is-empty", state.empty);
      };
      renderSubtitle();
      subtitleHeader.append(subtitleTitle, subtitleEdit);
      subtitleBlock.append(subtitleHeader, subtitle);
      item.append(subtitleBlock);
      inlineEditController.bind({
        noteId: note.id,
        button: subtitleEdit,
        content: subtitle,
        getInitialText: () => note.subtitleContext ?? "",
        restore: renderSubtitle,
        save(text) {
          return request({
            type: "UPDATE_NOTE_SUBTITLE",
            noteId: note.id,
            subtitleContext: text
          });
        },
        applySaved(response) {
          note.subtitleContext = response.note.subtitleContext;
          renderSubtitle();
        }
      });
    }
    if (note.transcriptionStatus === "transcribing" || note.transcriptionStatus === "pending") {
      const pending = document.createElement("span");
      pending.className = "note-pending";
      pending.textContent = note.pendingTranscription ? `\u4F7F\u7528 ${whisperModelLabel(note.pendingTranscription.modelId)} \u8F6C\u5199\u4E2D\u2026` : "\u672C\u5730\u8F6C\u5199\u4E2D\u2026";
      item.append(pending);
    }
    if (note.inputType === "voice") {
      const retranscribe = document.createElement("button");
      retranscribe.className = "note-retranscribe-button";
      retranscribe.type = "button";
      retranscribe.textContent = "\u7528\u5F53\u524D\u6A21\u578B\u91CD\u65B0\u8F6C\u5199";
      const unavailableReason = retranscriptionUnavailableReason(note);
      retranscribe.disabled = Boolean(unavailableReason);
      retranscribe.title = unavailableReason;
      retranscribe.addEventListener("click", async () => {
        retranscribe.disabled = true;
        try {
          await request({ type: "RETRANSCRIBE_NOTE", noteId: note.id });
          await refresh();
        } catch (error) {
          showToast(error.message);
          await refresh();
        }
      });
      item.append(retranscribe);
      if (unavailableReason) {
        const reason = document.createElement("span");
        reason.className = "note-retranscribe-reason";
        reason.textContent = unavailableReason;
        item.append(reason);
      }
    }
    if ((note.transcriptionRuns?.length ?? 0) > 1) {
      const results = document.createElement("details");
      results.className = "note-transcription-results";
      const summary = document.createElement("summary");
      summary.textContent = `\u67E5\u770B ${note.transcriptionRuns.length} \u4E2A\u8F6C\u5199\u7ED3\u679C`;
      results.append(summary);
      for (const run of note.transcriptionRuns) {
        const result = document.createElement("div");
        result.className = "note-transcription-result";
        const metadata = document.createElement("span");
        metadata.className = "note-transcription-meta";
        metadata.textContent = `${whisperModelLabel(run.modelId)} \xB7 ${formatTranscriptionTime(run.createdAt)}`;
        const text = document.createElement("p");
        text.textContent = run.text || "\uFF08\u65E0\u8BC6\u522B\u6587\u672C\uFF09";
        result.append(metadata, text);
        results.append(result);
      }
      item.append(results);
    }
    for (const warning of note.warnings ?? []) {
      const warningLine = document.createElement("span");
      warningLine.className = "note-pending";
      warningLine.textContent = warning;
      item.append(warningLine);
    }
    elements.noteList.append(item);
  }
  syncHistoryControls();
}
async function refresh() {
  if (inlineEditController.blocked) {
    sidePanelRefresh.requestRefresh({ type: "SIDE_PANEL_REFRESH_REQUEST" });
    return;
  }
  await refreshNow();
}
async function refreshNow() {
  return refreshRunner.run();
}
refreshRunner = createSidePanelRefreshRunner({
  async load() {
    const response = await request({ type: "GET_ACTIVE_STATE" });
    const nextWhisperStatus = await request({ type: "GET_WHISPER_STATUS" }).catch(() => whisperStatus);
    return { nextWhisperStatus, response };
  },
  apply({ nextWhisperStatus, response }) {
    whisperStatus = nextWhisperStatus;
    if (activeContext?.sessionId !== response.context?.sessionId || activeContextTabId !== sidePanelRefresh.tabId) {
      historyContextToken += 1;
    }
    activeContext = response.context;
    activeContextTabId = sidePanelRefresh.tabId;
    canUndo = response.history.canUndo;
    canRedo = response.history.canRedo;
    if (!activeContext) throw new Error("\u8BF7\u6253\u5F00 YouTube \u6216\u54D4\u54E9\u54D4\u54E9\u666E\u901A\u89C6\u9891\u9875");
    elements.videoTitle.textContent = activeContext.title;
    elements.videoUrl.href = activeContext.canonicalUrl;
    elements.videoUrl.hidden = false;
    elements.input.disabled = false;
    elements.voiceButton.disabled = false;
    renderNotes(response.notes);
  },
  applyError(error) {
    if (activeContext || activeContextTabId !== null) historyContextToken += 1;
    activeContext = null;
    activeContextTabId = null;
    canUndo = false;
    canRedo = false;
    elements.videoTitle.textContent = error.message;
    elements.videoUrl.hidden = true;
    elements.input.disabled = true;
    elements.voiceButton.disabled = true;
    elements.exportButton.disabled = true;
    renderNotes([]);
  },
  isBlocked: () => inlineEditController.blocked,
  defer() {
    sidePanelRefresh.requestRefresh({ type: "SIDE_PANEL_REFRESH_RESPONSE_DEFERRED" });
  }
});
async function beginTypedDraft() {
  if (currentDraft || draftPromise || !activeContext) return;
  draftPromise = request({ type: "BEGIN_TYPED_NOTE" });
  syncHistoryControls();
  try {
    const response = await draftPromise;
    currentDraft = response.note;
    elements.markerTime.textContent = formatTimestamp(currentDraft.seconds);
    elements.markerTime.hidden = false;
  } catch (error) {
    showToast(error.message);
    elements.input.blur();
  } finally {
    draftPromise = null;
    syncHistoryControls();
  }
}
async function commitTypedDraft() {
  if (draftPromise) await draftPromise.catch(() => {
  });
  if (!currentDraft) return;
  const noteId = currentDraft.id;
  const body = elements.input.value.trim();
  currentDraft = null;
  typedDraftSaving = true;
  elements.markerTime.hidden = true;
  elements.input.value = "";
  autoGrow();
  try {
    if (body) await request({ type: "COMMIT_TYPED_NOTE", noteId, body });
    else await request({ type: "CANCEL_NOTE", noteId });
    await refresh();
  } catch (error) {
    showToast(error.message);
  } finally {
    typedDraftSaving = false;
    syncHistoryControls();
  }
}
async function cancelTypedDraft() {
  if (draftPromise) await draftPromise.catch(() => {
  });
  if (!currentDraft) return;
  const noteId = currentDraft.id;
  currentDraft = null;
  typedDraftSaving = true;
  elements.input.value = "";
  elements.markerTime.hidden = true;
  autoGrow();
  try {
    await request({ type: "CANCEL_NOTE", noteId });
  } catch (error) {
    showToast(error.message);
  } finally {
    typedDraftSaving = false;
    syncHistoryControls();
  }
}
function setRecordingUi(active) {
  recording = active;
  syncHistoryControls();
  elements.recordingStatus.hidden = !active;
  elements.voiceButton.classList.toggle("is-recording", active);
  elements.voiceLabel.textContent = active ? "\u677E\u5F00\u7ED3\u675F" : "\u6309\u4F4F\u8BF4\u8BDD";
  clearInterval(recordingInterval);
  clearTimeout(recordingTimeout);
  if (!active) return;
  recordingStartedAt = Date.now();
  const update = () => {
    const seconds = Math.floor((Date.now() - recordingStartedAt) / 1e3);
    elements.recordingTimer.textContent = `${String(Math.floor(seconds / 60)).padStart(2, "0")}:${String(seconds % 60).padStart(2, "0")}`;
  };
  update();
  recordingInterval = setInterval(update, 250);
  recordingTimeout = setTimeout(() => void stopVoice("timeout"), 6e4);
}
async function startVoice() {
  if (recording || voiceStarting || !activeContext) return;
  voiceStarting = true;
  syncHistoryControls();
  try {
    if (!microphoneReady) {
      await openMicrophonePermissionPage();
      pendingVoiceStopReason = null;
      showToast("\u8BF7\u5728\u65B0\u9875\u9762\u5B8C\u6210\u9EA6\u514B\u98CE\u6388\u6743");
      return;
    }
    await request({ type: "VOICE_START_REQUEST" });
    setRecordingUi(true);
    if (pendingVoiceStopReason) {
      const reason = pendingVoiceStopReason;
      pendingVoiceStopReason = null;
      await stopVoice(reason);
    }
  } catch (error) {
    pendingVoiceStopReason = null;
    showToast(error.message);
  } finally {
    voiceStarting = false;
    syncHistoryControls();
  }
}
async function stopVoice(reason = "button-release") {
  if (voiceStarting && !recording) {
    pendingVoiceStopReason = reason;
    return;
  }
  if (!recording) return;
  setRecordingUi(false);
  voiceStopping = true;
  syncHistoryControls();
  try {
    await request({ type: "VOICE_STOP_REQUEST", reason });
    await refresh();
  } catch (error) {
    showToast(error.message);
  } finally {
    voiceStopping = false;
    syncHistoryControls();
  }
}
function shortcutLabel(code) {
  const labels = { AltRight: "\u53F3 Option / Alt", AltLeft: "\u5DE6 Option / Alt", Space: "\u7A7A\u683C" };
  return labels[code] ?? code;
}
async function renderWhisperStatus() {
  const status = await request({ type: "GET_WHISPER_STATUS" });
  whisperStatus = status;
  const labels = {
    disabled: "\u5C1A\u672A\u542F\u7528\u3002\u8BF7\u9009\u62E9\u6A21\u578B\u540E\u4E0B\u8F7D\u3002",
    downloading: "\u6B63\u5728\u4E0B\u8F7D\u5E76\u6821\u9A8C\u6A21\u578B\uFF0C\u53EF\u5728\u4E2D\u65AD\u540E\u7EED\u4F20\u3002",
    ready: "\u5DF2\u542F\u7528\uFF0C\u53EF\u5728\u672C\u673A\u8F6C\u5199\u3002",
    recording: "\u6B63\u5728\u5F55\u97F3\uFF0C\u677E\u5F00\u540E\u4F1A\u5728\u672C\u673A\u8F6C\u5199\u3002",
    transcribing: "\u6B63\u5728\u672C\u673A\u8F6C\u5199\uFF0C\u89C6\u9891\u53EF\u7EE7\u7EED\u64AD\u653E\u3002",
    error: `\u672C\u5730\u8BED\u97F3\u5F02\u5E38\uFF1A${status.whisperError || "\u672A\u77E5\u9519\u8BEF"}`
  };
  const selectedModelId = pendingWhisperModelId ?? status.selectedModelId;
  if (elements.whisperModelSelect.options.length !== status.models.length) {
    elements.whisperModelSelect.replaceChildren(...status.models.map((model) => {
      const option = document.createElement("option");
      option.value = model.id;
      option.textContent = `${model.label}${model.recommended ? "\uFF08\u63A8\u8350\uFF09" : ""}`;
      return option;
    }));
  }
  elements.whisperModelSelect.value = selectedModelId;
  const selectedModel = status.models.find(({ id }) => id === selectedModelId);
  const downloadingModel = status.models.find(({ id }) => id === status.download?.modelId);
  const busy = ["downloading", "recording", "transcribing"].includes(status.whisperState) || Boolean(status.download);
  const cached = status.cachedModelIds.includes(selectedModelId);
  elements.whisperDetail.textContent = downloadingModel ? `\u6B63\u5728\u4E0B\u8F7D\u5E76\u6821\u9A8C ${downloadingModel.label}\uFF08\u5DF2\u4E0B\u8F7D ${Math.round(
    (status.download.downloadedBytes ?? 0) / 1024 / 1024
  )} / ${Math.round(downloadingModel.size / 1024 / 1024)} MiB\uFF09\u3002` : labels[status.whisperState] ?? labels.disabled;
  elements.whisperModelAction.textContent = cached ? "\u4F7F\u7528\u6B64\u6A21\u578B" : "\u4E0B\u8F7D\u5E76\u4F7F\u7528";
  elements.whisperModelSelect.disabled = busy;
  elements.whisperModelAction.disabled = busy;
  elements.whisperModelWarning.hidden = selectedModel?.experimental !== true;
  elements.whisperModelWarning.textContent = selectedModel?.experimental ? "\u7EA6 514 MiB\uFF0C\u5F53\u524D\u8BBE\u5907\u53EF\u80FD\u8F6C\u5199\u8F83\u6162" : "";
}
elements.input.addEventListener("focus", () => void beginTypedDraft());
elements.input.addEventListener("input", autoGrow);
elements.input.addEventListener("compositionstart", () => {
  isComposing = true;
});
elements.input.addEventListener("compositionend", () => {
  isComposing = false;
  if (commitAfterComposition) {
    commitAfterComposition = false;
    void commitTypedDraft();
  }
});
elements.input.addEventListener("blur", () => {
  if (isComposing) {
    commitAfterComposition = true;
    setTimeout(() => {
      if (!commitAfterComposition) return;
      isComposing = false;
      commitAfterComposition = false;
      void commitTypedDraft();
    }, 300);
  } else {
    void commitTypedDraft();
  }
});
elements.input.addEventListener("keydown", (event) => {
  if (event.isComposing) return;
  if (event.key === "Escape") {
    event.preventDefault();
    void cancelTypedDraft().then(() => elements.input.blur());
  } else if (event.key === "Enter" && (event.metaKey || event.ctrlKey)) {
    event.preventDefault();
    void commitTypedDraft().then(() => elements.input.blur());
  }
});
elements.voiceButton.addEventListener("pointerdown", (event) => {
  event.preventDefault();
  elements.voiceButton.setPointerCapture(event.pointerId);
  void startVoice();
});
elements.voiceButton.addEventListener("pointerup", (event) => {
  event.preventDefault();
  void stopVoice();
});
elements.voiceButton.addEventListener("pointercancel", () => void stopVoice("pointer-cancel"));
elements.screenshotPermissionButton.addEventListener("click", async () => {
  elements.screenshotPermissionButton.disabled = true;
  try {
    const granted = await chrome.permissions.request({ origins: SCREENSHOT_ORIGINS });
    if (!granted) throw new Error("\u622A\u56FE\u6388\u6743\u5DF2\u53D6\u6D88");
    showToast("\u64AD\u653E\u5668\u622A\u56FE\u5DF2\u542F\u7528");
  } catch (error) {
    showToast(error.message);
  } finally {
    await renderPermissionStatus();
  }
});
elements.microphonePermissionButton.addEventListener("click", async () => {
  elements.microphonePermissionButton.disabled = true;
  try {
    await openMicrophonePermissionPage();
    showToast("\u8BF7\u5728\u65B0\u9875\u9762\u5B8C\u6210\u9EA6\u514B\u98CE\u6388\u6743");
  } catch (error) {
    showToast(error.message);
  } finally {
    await renderPermissionStatus();
  }
});
elements.subtitleEnabled.addEventListener("change", async () => {
  const previous = subtitleSettings;
  elements.subtitleWindowSeconds.disabled = !elements.subtitleEnabled.checked;
  try {
    await chrome.storage.local.set({
      subtitleEnabled: elements.subtitleEnabled.checked
    });
  } catch (error) {
    elements.subtitleEnabled.checked = previous.enabled;
    elements.subtitleWindowSeconds.disabled = !previous.enabled;
    showToast(error.message);
  }
});
elements.subtitleWindowSeconds.addEventListener("change", async () => {
  const previous = subtitleSettings;
  try {
    await chrome.storage.local.set({
      subtitleWindowSeconds: Number(elements.subtitleWindowSeconds.value)
    });
  } catch (error) {
    elements.subtitleWindowSeconds.value = String(previous.windowSeconds);
    showToast(error.message);
  }
});
elements.screenshotDialogClose.addEventListener("click", () => {
  elements.screenshotDialog.close();
});
elements.screenshotDialog.addEventListener("click", (event) => {
  const bounds = elements.screenshotDialog.getBoundingClientRect();
  const outsideDialog = event.clientX < bounds.left || event.clientX > bounds.right || event.clientY < bounds.top || event.clientY > bounds.bottom;
  if (event.target === elements.screenshotDialog && outsideDialog) {
    elements.screenshotDialog.close();
  }
});
elements.screenshotDialog.addEventListener("close", () => {
  elements.screenshotDialogImage.removeAttribute("src");
});
elements.historyConfirmDialog.addEventListener("close", () => {
  if (elements.historyConfirmDialog.returnValue !== "confirm") {
    historyConfirmationController.cancel();
    return;
  }
  void historyConfirmationController.confirm();
});
elements.undoButton.addEventListener("click", () => {
  if (!canRunHistoryAction("undo")) return;
  void runHistoryOperation({
    type: "UNDO_NOTE_ACTION",
    sessionId: activeContext.sessionId,
    tabId: sidePanelRefresh.tabId
  });
});
elements.redoButton.addEventListener("click", () => {
  if (!canRunHistoryAction("redo")) return;
  void runHistoryOperation({
    type: "REDO_NOTE_ACTION",
    sessionId: activeContext.sessionId,
    tabId: sidePanelRefresh.tabId
  });
});
elements.clearButton.addEventListener("click", () => {
  if (!canRunHistoryAction("clear")) return;
  confirmHistoryAction({
    title: "\u6E05\u7A7A\u5168\u90E8\u6807\u8BB0\uFF1F",
    description: `\u5C06\u6E05\u7A7A ${savedNoteCount()} \u6761\u5DF2\u4FDD\u5B58\u6807\u8BB0\u3002\u53EF\u901A\u8FC7\u64A4\u9500\u6062\u590D\u3002`
  }, { operation: "clear" });
});
elements.exportButton.addEventListener("click", async () => {
  if (!activeContext) return;
  elements.exportButton.disabled = true;
  try {
    const result = await request({ type: "EXPORT_SESSION", sessionId: activeContext.sessionId });
    showToast(`\u5DF2\u751F\u6210 ${result.noteCount} \u6761\u6807\u8BB0\u7684 ZIP`);
  } catch (error) {
    showToast(error.message);
  } finally {
    elements.exportButton.disabled = false;
  }
});
elements.whisperModelSelect.addEventListener("change", () => {
  pendingWhisperModelId = elements.whisperModelSelect.value;
  void renderWhisperStatus();
});
elements.whisperModelAction.addEventListener("click", async () => {
  elements.whisperModelAction.disabled = true;
  try {
    const status = await request({ type: "GET_WHISPER_STATUS" });
    const modelId = elements.whisperModelSelect.value;
    if (status.cachedModelIds.includes(modelId)) {
      await request({ type: "SELECT_WHISPER_MODEL", modelId });
      showToast("\u5DF2\u5207\u6362\u672C\u5730 Whisper \u6A21\u578B");
    } else {
      const source = modelId === "base-q5_1" ? await request({ type: "CHECK_BUNDLED_MODEL" }) : { bundled: false };
      if (!source.bundled) {
        const granted = await chrome.permissions.request({ origins: WHISPER_ORIGINS });
        if (!granted) throw new Error("\u672A\u6388\u6743\u4E0B\u8F7D\u672C\u5730\u8BED\u97F3\u6A21\u578B");
      }
      await request({ type: "ENABLE_WHISPER", modelId });
      showToast("\u672C\u5730 Whisper \u5DF2\u542F\u7528");
    }
    pendingWhisperModelId = null;
  } catch (error) {
    showToast(error.message);
  } finally {
    await renderWhisperStatus();
  }
});
elements.keyButton.addEventListener("click", () => {
  elements.keyButton.classList.add("is-listening");
  elements.keyButton.textContent = "\u8BF7\u6309\u4E00\u4E2A\u952E\u2026";
  elements.keyButton.focus();
});
elements.keyButton.addEventListener("keydown", async (event) => {
  if (!elements.keyButton.classList.contains("is-listening")) return;
  event.preventDefault();
  if (event.code === "Escape") {
    elements.keyButton.classList.remove("is-listening");
    const { shortcutCode = "AltRight" } = await chrome.storage.local.get("shortcutCode");
    elements.keyButton.textContent = shortcutLabel(shortcutCode);
    return;
  }
  try {
    await request({ type: "SET_SHORTCUT", code: event.code });
    elements.keyButton.textContent = shortcutLabel(event.code);
    showToast(`\u6309\u4F4F\u8BF4\u8BDD\u952E\u5DF2\u6539\u4E3A ${shortcutLabel(event.code)}`);
  } catch (error) {
    showToast(error.message);
  } finally {
    elements.keyButton.classList.remove("is-listening");
  }
});
document.addEventListener("keydown", (event) => {
  const operation = historyShortcut(event);
  if (!operation || !canRunHistoryAction(operation)) return;
  event.preventDefault();
  if (operation === "undo") {
    void runHistoryOperation({
      type: "UNDO_NOTE_ACTION",
      sessionId: activeContext.sessionId,
      tabId: sidePanelRefresh.tabId
    });
  } else {
    void runHistoryOperation({
      type: "REDO_NOTE_ACTION",
      sessionId: activeContext.sessionId,
      tabId: sidePanelRefresh.tabId
    });
  }
});
chrome.runtime.onMessage.addListener((message) => {
  if (isSidePanelRefreshMessage(message)) {
    sidePanelRefresh.handleContextChanged(message);
  }
});
document.addEventListener("visibilitychange", () => {
  sidePanelRefresh.handleVisibilityChange(document.visibilityState === "visible");
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && (changes.whisperState || changes.whisperSelectedModel || changes.whisperDownloadModel || changes.whisperDownloadedBytes)) {
    void renderWhisperStatus();
  }
  if (area === "local" && changes.shortcutCode?.newValue) {
    elements.keyButton.textContent = shortcutLabel(changes.shortcutCode.newValue);
  }
  if (area === "local" && changes.noteSortOrder) {
    noteSortBinding.sync(changes.noteSortOrder.newValue);
  }
  if (area === "local" && changes.microphoneReady) {
    microphoneReady = changes.microphoneReady.newValue === true;
    void renderPermissionStatus();
  }
  if (area === "local" && (changes.subtitleEnabled || changes.subtitleWindowSeconds)) {
    subtitleSettings = normalizeSubtitleSettings({
      subtitleEnabled: changes.subtitleEnabled ? changes.subtitleEnabled.newValue : subtitleSettings.enabled,
      subtitleWindowSeconds: changes.subtitleWindowSeconds ? changes.subtitleWindowSeconds.newValue : subtitleSettings.windowSeconds
    });
    syncSubtitleSettingsControls();
    sidePanelRefresh.requestRefresh({ type: "SUBTITLE_SETTINGS_CHANGED" });
  }
});
window.addEventListener("pagehide", () => {
  ++renderGeneration;
  closeScreenshotDialog();
  stopNoteMedia(elements.noteList);
  assetUrls.revokeAll();
  if (recording || voiceStarting) {
    void chrome.runtime.sendMessage({ type: "CANCEL_PENDING_VOICE", reason: "sidepanel-closed" });
  }
  if (currentDraft) {
    void chrome.runtime.sendMessage({ type: "CANCEL_NOTE", noteId: currentDraft.id });
  } else if (draftPromise) {
    void draftPromise.then((response) => chrome.runtime.sendMessage({
      type: "CANCEL_NOTE",
      noteId: response.note.id
    })).catch(() => {
    });
  }
});
subtitleSettings = normalizeSubtitleSettings(
  await chrome.storage.local.get({
    subtitleEnabled: true,
    subtitleWindowSeconds: 20
  })
);
syncSubtitleSettingsControls();
await initializeSidepanel({
  storage: chrome.storage,
  onShortcutCode: (shortcutCode) => {
    elements.keyButton.textContent = shortcutLabel(shortcutCode);
  },
  noteSortBinding,
  setPanelContext: async () => {
    const panelContext = await request({ type: "GET_SIDEPANEL_CONTEXT" });
    sidePanelRefresh.setTabId(panelContext.tabId);
  },
  refresh,
  renderWhisperStatus,
  renderPermissionStatus: () => renderPermissionStatus({ expandIfNeeded: true })
});
