// src/core/microphone-access.js
var MICROPHONE_CONSTRAINTS = Object.freeze({
  audio: Object.freeze({
    channelCount: 1,
    echoCancellation: true,
    noiseSuppression: true,
    autoGainControl: true
  })
});
async function verifyMicrophoneAccess(getUserMedia) {
  let stream;
  try {
    stream = await getUserMedia(MICROPHONE_CONSTRAINTS);
    return true;
  } finally {
    for (const track of stream?.getTracks() ?? []) track.stop();
  }
}

// src/microphone-permission.js
var button = document.querySelector("#grant-microphone-button");
var status = document.querySelector("#permission-status");
function setStatus(message, { error = false } = {}) {
  status.textContent = message;
  status.classList.toggle("is-error", error);
}
async function saveReady(ready, error = "") {
  await chrome.storage.local.set({
    microphoneReady: ready,
    microphoneLastError: error
  });
}
async function closePermissionTab() {
  const tab = await chrome.tabs.getCurrent();
  if (tab?.id) await chrome.tabs.remove(tab.id);
}
async function returnToSourceTab() {
  const response = await chrome.runtime.sendMessage({ type: "MICROPHONE_PERMISSION_GRANTED" });
  if (!response?.ok) throw new Error(response?.error ?? "\u65E0\u6CD5\u8FD4\u56DE\u539F\u89C6\u9891\u9875\u9762");
  if (!response.returned) {
    setStatus("\u9EA6\u514B\u98CE\u5DF2\u6388\u6743\uFF0C\u4F46\u539F\u89C6\u9891\u9875\u9762\u5DF2\u7ECF\u5173\u95ED\uFF0C\u8BF7\u624B\u52A8\u8FD4\u56DE\u8BFE\u7A0B\u9875\u9762\u3002", { error: true });
    return false;
  }
  setStatus("\u6388\u6743\u6210\u529F\uFF0C\u6B63\u5728\u8FD4\u56DE\u89C6\u9891\u9875\u9762\u2026");
  setTimeout(() => void closePermissionTab(), 700);
  return true;
}
async function readPermission() {
  try {
    const permission = await navigator.permissions.query({ name: "microphone" });
    if (permission.state === "granted") {
      await saveReady(true);
      button.disabled = true;
      button.textContent = "\u5DF2\u6388\u6743";
      await returnToSourceTab();
    } else if (permission.state === "denied") {
      await saveReady(false, "\u9EA6\u514B\u98CE\u6743\u9650\u5DF2\u88AB\u62D2\u7EDD");
      setStatus("Edge \u5DF2\u62D2\u7EDD\u9EA6\u514B\u98CE\u6743\u9650\uFF0C\u8BF7\u5728\u5730\u5740\u680F\u6743\u9650\u8BBE\u7F6E\u4E2D\u6539\u4E3A\u5141\u8BB8\u540E\u91CD\u8BD5\u3002", {
        error: true
      });
    }
  } catch {
  }
}
button.addEventListener("click", async () => {
  button.disabled = true;
  setStatus("\u7B49\u5F85 Edge \u9EA6\u514B\u98CE\u6743\u9650\u786E\u8BA4\u2026");
  try {
    if (!navigator.mediaDevices?.getUserMedia) throw new Error("\u5F53\u524D Edge \u65E0\u6CD5\u8BBF\u95EE\u9EA6\u514B\u98CE");
    await verifyMicrophoneAccess(
      navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices)
    );
    await saveReady(true);
    button.textContent = "\u6388\u6743\u6210\u529F";
    await returnToSourceTab();
  } catch (error) {
    const message = String(error?.message ?? error ?? "\u6388\u6743\u5931\u8D25");
    await saveReady(false, message);
    setStatus(`\u6388\u6743\u5931\u8D25\uFF1A${message}`, { error: true });
    button.disabled = false;
    button.textContent = "\u91CD\u65B0\u6388\u6743";
  }
});
await readPermission();
