// src/core/screenshot.js
function computeScreenshotCrop(rect, viewport, image, maxEdge = 1600) {
  const scaleX = image.width / viewport.width;
  const scaleY = image.height / viewport.height;
  const left = Math.max(0, rect.x);
  const top = Math.max(0, rect.y);
  const right = Math.min(viewport.width, rect.x + rect.width);
  const bottom = Math.min(viewport.height, rect.y + rect.height);
  const sx = Math.max(0, Math.floor(left * scaleX));
  const sy = Math.max(0, Math.floor(top * scaleY));
  const sw = Math.max(1, Math.ceil(right * scaleX) - sx);
  const sh = Math.max(1, Math.ceil(bottom * scaleY) - sy);
  const ratio = Math.min(1, maxEdge / Math.max(sw, sh));
  return {
    sx,
    sy,
    sw,
    sh,
    outputWidth: Math.max(1, Math.round(sw * ratio)),
    outputHeight: Math.max(1, Math.round(sh * ratio))
  };
}

// src/core/note-history.js
var NOTE_HISTORY_LIMIT = 50;
var ACTION_TYPES = /* @__PURE__ */ new Set([
  "add-note",
  "edit-body",
  "edit-subtitle",
  "delete-note",
  "clear-session"
]);
function emptyNoteHistory(sessionId) {
  return { sessionId, undo: [], redo: [], updatedAt: 0 };
}
function recordNoteAction(history, action) {
  if (!ACTION_TYPES.has(action?.type) || !Array.isArray(action.noteIds)) {
    throw new Error("\u65E0\u6548\u7684\u7B14\u8BB0\u5386\u53F2\u52A8\u4F5C");
  }
  return {
    ...history,
    undo: [...history.undo, structuredClone(action)].slice(-NOTE_HISTORY_LIMIT),
    redo: [],
    updatedAt: action.createdAt
  };
}
function undoNoteHistory(history) {
  const action = history.undo.at(-1) ?? null;
  if (action === null) {
    return { action, history };
  }
  return {
    action,
    history: {
      ...history,
      undo: history.undo.slice(0, -1),
      redo: [...history.redo, action]
    }
  };
}
function redoNoteHistory(history) {
  const action = history.redo.at(-1) ?? null;
  if (action === null) {
    return { action, history };
  }
  return {
    action,
    history: {
      ...history,
      undo: [...history.undo, action],
      redo: history.redo.slice(0, -1)
    }
  };
}
function referencedNoteIds(history) {
  return new Set([...history.undo, ...history.redo].flatMap(({ noteIds }) => noteIds));
}

// src/core/storage.js
var DATABASE_VERSION = 2;
function requestResult(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}
function transactionDone(transaction) {
  return new Promise((resolve, reject) => {
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error);
    transaction.onabort = () => reject(transaction.error ?? new Error("IndexedDB \u4E8B\u52A1\u5DF2\u4E2D\u6B62"));
  });
}
function actionId() {
  return globalThis.crypto.randomUUID();
}
function restoreNote(note, now) {
  const { deletedAt, ...visibleNote } = note;
  return { ...visibleNote, updatedAt: now };
}
function deleteNoteAt(note, now) {
  return { ...note, deletedAt: now, updatedAt: now };
}
function historyAction(type, noteIds, now, values = {}) {
  return {
    id: actionId(),
    type,
    noteIds,
    ...values,
    createdAt: now
  };
}
var VideoNotesRepository = class {
  constructor({
    databaseName = "video-notes",
    indexedDB = globalThis.indexedDB,
    IDBKeyRange = globalThis.IDBKeyRange
  } = {}) {
    if (!indexedDB) throw new Error("\u5F53\u524D\u73AF\u5883\u4E0D\u652F\u6301 IndexedDB");
    this.databaseName = databaseName;
    this.indexedDB = indexedDB;
    this.IDBKeyRange = IDBKeyRange;
    this.db = null;
    this.dbPromise = this.open();
  }
  open() {
    const request = this.indexedDB.open(this.databaseName, DATABASE_VERSION);
    request.onupgradeneeded = () => {
      const database = request.result;
      if (!database.objectStoreNames.contains("sessions")) {
        database.createObjectStore("sessions", { keyPath: "id" });
      }
      if (!database.objectStoreNames.contains("notes")) {
        const notes = database.createObjectStore("notes", { keyPath: "id" });
        notes.createIndex("sessionId", "sessionId", { unique: false });
      }
      if (!database.objectStoreNames.contains("assets")) {
        database.createObjectStore("assets", { keyPath: "key" });
      }
      if (!database.objectStoreNames.contains("history")) {
        database.createObjectStore("history", { keyPath: "sessionId" });
      }
    };
    return requestResult(request).then((database) => {
      this.db = database;
      return database;
    });
  }
  async read(storeName, key) {
    const database = await this.dbPromise;
    return requestResult(database.transaction(storeName).objectStore(storeName).get(key));
  }
  async write(storeName, value) {
    const database = await this.dbPromise;
    const transaction = database.transaction(storeName, "readwrite");
    transaction.objectStore(storeName).put(value);
    await transactionDone(transaction);
    return value;
  }
  async remove(storeName, key) {
    const database = await this.dbPromise;
    const transaction = database.transaction(storeName, "readwrite");
    transaction.objectStore(storeName).delete(key);
    await transactionDone(transaction);
  }
  putSession(session) {
    return this.write("sessions", session);
  }
  getSession(id) {
    return this.read("sessions", id);
  }
  putNote(note) {
    return this.write("notes", note);
  }
  getNote(id) {
    return this.read("notes", id);
  }
  async updateNote(id, updater) {
    const database = await this.dbPromise;
    return new Promise((resolve, reject) => {
      const transaction = database.transaction("notes", "readwrite");
      const store = transaction.objectStore("notes");
      const request = store.get(id);
      let updated;
      request.onsuccess = () => {
        if (request.result === void 0) {
          transaction.abort();
          reject(new Error(`\u6807\u8BB0\u4E0D\u5B58\u5728\uFF1A${id}`));
          return;
        }
        try {
          updated = updater(request.result);
          store.put(updated);
        } catch (error) {
          transaction.abort();
          reject(error);
        }
      };
      request.onerror = () => reject(request.error);
      transaction.oncomplete = () => resolve(updated);
      transaction.onerror = () => reject(transaction.error);
      transaction.onabort = () => reject(transaction.error ?? new Error("\u66F4\u65B0\u6807\u8BB0\u5931\u8D25"));
    });
  }
  deleteNote(id) {
    return this.remove("notes", id);
  }
  async listNotes(sessionId) {
    const database = await this.dbPromise;
    const transaction = database.transaction("notes");
    const index = transaction.objectStore("notes").index("sessionId");
    const notes = await requestResult(index.getAll(this.IDBKeyRange.only(sessionId)));
    return notes.filter((note) => note.deletedAt === void 0).sort((left, right) => left.createdAt - right.createdAt);
  }
  async listPendingTranscriptions() {
    const database = await this.dbPromise;
    const notes = await requestResult(
      database.transaction("notes").objectStore("notes").getAll()
    );
    return notes.filter((note) => note.status === "saved" && note.deletedAt === void 0 && Boolean(note.audioKey) && ["pending", "transcribing"].includes(note.transcriptionStatus));
  }
  putAsset(key, blob) {
    return this.write("assets", {
      key,
      blob,
      mimeType: blob.type,
      createdAt: Date.now()
    });
  }
  async getAsset(key) {
    return (await this.read("assets", key))?.blob;
  }
  deleteAsset(key) {
    return this.remove("assets", key);
  }
  async mutateHistory(sessionId, now, callback) {
    const database = await this.dbPromise;
    return new Promise((resolve, reject) => {
      const transaction = database.transaction(["notes", "history", "assets"], "readwrite");
      const noteStore = transaction.objectStore("notes");
      const historyStore = transaction.objectStore("history");
      const assetStore = transaction.objectStore("assets");
      const notesRequest = noteStore.getAll();
      const historyRequest = historyStore.get(sessionId);
      let allNotes;
      let storedHistory;
      let notesLoaded = false;
      let historyLoaded = false;
      let outcome;
      let settled = false;
      let abortError = null;
      const rememberAbortError = (error) => {
        if (abortError === null) abortError = error;
      };
      const run = () => {
        if (!notesLoaded || !historyLoaded) return;
        const notes = new Map(
          allNotes.filter((note) => note.sessionId === sessionId).map((note) => [note.id, note])
        );
        const history = storedHistory ?? emptyNoteHistory(sessionId);
        try {
          outcome = callback({ notes, history }) ?? {};
          const nextHistory = outcome.history ?? (outcome.action ? recordNoteAction(history, outcome.action) : history);
          for (const note of outcome.changedNotes ?? []) {
            noteStore.put(note);
          }
          if (outcome.action || outcome.history) {
            historyStore.put(nextHistory);
          }
          if (outcome.changed) {
            const referencedIds = referencedNoteIds(nextHistory);
            const allNotesById = new Map(allNotes.map((note) => [note.id, note]));
            for (const note of outcome.changedNotes ?? []) {
              allNotesById.set(note.id, note);
            }
            const deletedNotes = [...notes.values()].filter((note) => note.deletedAt !== void 0 && !referencedIds.has(note.id));
            const deletedNoteIds = new Set(deletedNotes.map((note) => note.id));
            const retainedAssetKeys = new Set(
              [...allNotesById.values()].filter((note) => !deletedNoteIds.has(note.id)).flatMap((note) => [note.screenshotKey, note.audioKey]).filter(Boolean)
            );
            for (const note of deletedNotes) {
              noteStore.delete(note.id);
              if (note.screenshotKey && !retainedAssetKeys.has(note.screenshotKey)) {
                assetStore.delete(note.screenshotKey);
              }
              if (note.audioKey && !retainedAssetKeys.has(note.audioKey)) {
                assetStore.delete(note.audioKey);
              }
            }
          }
        } catch (error) {
          rememberAbortError(error);
          transaction.abort();
        }
      };
      notesRequest.onsuccess = () => {
        allNotes = notesRequest.result;
        notesLoaded = true;
        run();
      };
      historyRequest.onsuccess = () => {
        storedHistory = historyRequest.result;
        historyLoaded = true;
        run();
      };
      notesRequest.onerror = () => rememberAbortError(notesRequest.error);
      historyRequest.onerror = () => rememberAbortError(historyRequest.error);
      transaction.oncomplete = () => {
        if (!settled) {
          settled = true;
          resolve(outcome?.result);
        }
      };
      transaction.onerror = () => rememberAbortError(transaction.error);
      transaction.onabort = () => {
        if (!settled) {
          settled = true;
          reject(abortError ?? transaction.error ?? new Error("\u7B14\u8BB0\u5386\u53F2\u66F4\u65B0\u5931\u8D25"));
        }
      };
    });
  }
  async commitSavedNote(id, changes, now = Date.now()) {
    const existing = await this.getNote(id);
    if (existing === void 0) throw new Error(`\u6807\u8BB0\u4E0D\u5B58\u5728\uFF1A${id}`);
    return this.mutateHistory(existing.sessionId, now, ({ notes }) => {
      const note = notes.get(id);
      if (note === void 0) throw new Error(`\u6807\u8BB0\u4E0D\u5B58\u5728\uFF1A${id}`);
      const updated = { ...note, ...changes, updatedAt: now };
      const becameSaved = note.status !== "saved" && updated.status === "saved";
      notes.set(id, updated);
      return {
        changed: true,
        changedNotes: [updated],
        action: becameSaved ? historyAction("add-note", [id], now) : void 0,
        result: updated
      };
    });
  }
  mutateNoteValue(id, field, value, type, now, incrementsUserEditVersion) {
    return this.getNote(id).then((existing) => {
      if (existing === void 0) throw new Error(`\u6807\u8BB0\u4E0D\u5B58\u5728\uFF1A${id}`);
      return this.mutateHistory(existing.sessionId, now, ({ notes }) => {
        const note = notes.get(id);
        if (note === void 0) throw new Error(`\u6807\u8BB0\u4E0D\u5B58\u5728\uFF1A${id}`);
        if (note.status !== "saved" || note.deletedAt !== void 0) {
          throw new Error("\u7B14\u8BB0\u5386\u53F2\u52A8\u4F5C\u5DF2\u8FC7\u671F");
        }
        if (note[field] === value) return { changed: false, result: note };
        const updated = {
          ...note,
          [field]: value,
          ...incrementsUserEditVersion ? { userEditVersion: (note.userEditVersion ?? 0) + 1 } : {},
          updatedAt: now
        };
        notes.set(id, updated);
        return {
          changed: true,
          changedNotes: [updated],
          action: historyAction(type, [id], now, { before: note[field] ?? "", after: value }),
          result: updated
        };
      });
    });
  }
  editNoteBody(id, value, now = Date.now()) {
    return this.mutateNoteValue(
      id,
      "body",
      String(value ?? "").trim(),
      "edit-body",
      now,
      true
    );
  }
  editNoteSubtitle(id, value, now = Date.now()) {
    return this.mutateNoteValue(
      id,
      "subtitleContext",
      String(value ?? "").trim(),
      "edit-subtitle",
      now,
      false
    );
  }
  deleteSavedNote(id, now = Date.now()) {
    return this.getNote(id).then((existing) => {
      if (existing === void 0) throw new Error(`\u6807\u8BB0\u4E0D\u5B58\u5728\uFF1A${id}`);
      return this.mutateHistory(existing.sessionId, now, ({ notes }) => {
        const note = notes.get(id);
        if (note === void 0 || note.deletedAt !== void 0) {
          throw new Error("\u7B14\u8BB0\u5386\u53F2\u52A8\u4F5C\u5DF2\u8FC7\u671F");
        }
        const updated = deleteNoteAt(note, now);
        notes.set(id, updated);
        return {
          changed: true,
          changedNotes: [updated],
          action: historyAction("delete-note", [id], now),
          result: updated
        };
      });
    });
  }
  clearSessionNotes(sessionId, now = Date.now()) {
    return this.mutateHistory(sessionId, now, ({ notes }) => {
      const visibleNotes = [...notes.values()].filter((note) => note.deletedAt === void 0);
      if (visibleNotes.length === 0) return { changed: false, result: [] };
      const changedNotes = visibleNotes.map((note) => {
        const updated = deleteNoteAt(note, now);
        notes.set(note.id, updated);
        return updated;
      });
      return {
        changed: true,
        changedNotes,
        action: historyAction("clear-session", visibleNotes.map((note) => note.id), now),
        result: changedNotes
      };
    });
  }
  applyHistoryAction(notes, action, undo, now) {
    const actionNotes = action.noteIds.map((id) => notes.get(id));
    if (actionNotes.some((note) => note === void 0)) {
      throw new Error("\u7B14\u8BB0\u5386\u53F2\u52A8\u4F5C\u5DF2\u8FC7\u671F");
    }
    const isEdit = action.type === "edit-body" || action.type === "edit-subtitle";
    const shouldDelete = action.type === "add-note" === undo;
    if (isEdit) {
      const field = action.type === "edit-body" ? "body" : "subtitleContext";
      const expected = undo ? action.after : action.before;
      if (actionNotes.some((note) => note.deletedAt !== void 0 || note[field] !== expected)) {
        throw new Error("\u7B14\u8BB0\u5386\u53F2\u52A8\u4F5C\u5DF2\u8FC7\u671F");
      }
      return actionNotes.map((note) => {
        const updated = {
          ...note,
          [field]: undo ? action.before : action.after,
          ...action.type === "edit-body" ? { userEditVersion: (note.userEditVersion ?? 0) + 1 } : {},
          updatedAt: now
        };
        notes.set(updated.id, updated);
        return updated;
      });
    }
    if (actionNotes.some((note) => note.deletedAt !== void 0 !== !shouldDelete)) {
      throw new Error("\u7B14\u8BB0\u5386\u53F2\u52A8\u4F5C\u5DF2\u8FC7\u671F");
    }
    return actionNotes.map((note) => {
      const updated = shouldDelete ? deleteNoteAt(note, now) : restoreNote(note, now);
      notes.set(updated.id, updated);
      return updated;
    });
  }
  changeHistoryStack(sessionId, now, changeHistory) {
    return this.mutateHistory(sessionId, now, ({ notes, history }) => {
      const { action, history: nextHistory } = changeHistory(history);
      if (action === null) return { changed: false, result: null };
      const changedNotes = this.applyHistoryAction(notes, action, changeHistory === undoNoteHistory, now);
      return {
        changed: true,
        changedNotes,
        history: { ...nextHistory, updatedAt: now },
        result: action
      };
    });
  }
  undoNoteAction(sessionId, now = Date.now()) {
    return this.changeHistoryStack(sessionId, now, undoNoteHistory);
  }
  redoNoteAction(sessionId, now = Date.now()) {
    return this.changeHistoryStack(sessionId, now, redoNoteHistory);
  }
  async getNoteHistoryState(sessionId) {
    const history = await this.read("history", sessionId);
    return {
      canUndo: Boolean(history?.undo.length),
      canRedo: Boolean(history?.redo.length)
    };
  }
  close() {
    if (this.db) this.db.close();
    else void this.dbPromise.then((database) => database.close());
  }
  async destroy() {
    const database = await this.dbPromise;
    database.close();
    await requestResult(this.indexedDB.deleteDatabase(this.databaseName));
  }
};

// src/core/note-history-commands.js
var NOTE_HISTORY_COMMAND_TYPES = /* @__PURE__ */ new Set([
  "GET_ACTIVE_STATE",
  "COMMIT_TYPED_NOTE",
  "UPDATE_NOTE_BODY",
  "UPDATE_NOTE_SUBTITLE",
  "DELETE_NOTE",
  "CLEAR_SESSION_NOTES",
  "UNDO_NOTE_ACTION",
  "REDO_NOTE_ACTION"
]);
function isNoteHistoryCommand(type) {
  return NOTE_HISTORY_COMMAND_TYPES.has(type);
}
function createNoteHistoryCommandRouter({
  repository: repository2,
  getCurrentContext,
  onTypedNoteCommitted = async () => {
  }
}) {
  async function requireCurrentSession(sessionId, request) {
    const context = await getCurrentContext(request);
    if (!context || context.sessionId !== sessionId) throw new Error("\u5F53\u524D\u9875\u9762\u4F1A\u8BDD\u4E0D\u5339\u914D");
    return context;
  }
  return async function route(message, request) {
    switch (message.type) {
      case "GET_ACTIVE_STATE": {
        const context = await getCurrentContext(request);
        if (!context) {
          return {
            context: null,
            notes: [],
            history: { canUndo: false, canRedo: false }
          };
        }
        const history = await repository2.getNoteHistoryState(context.sessionId);
        return {
          context,
          notes: await repository2.listNotes(context.sessionId),
          history: { canUndo: history.canUndo, canRedo: history.canRedo }
        };
      }
      case "COMMIT_TYPED_NOTE": {
        const note = await repository2.commitSavedNote(message.noteId, {
          body: String(message.body ?? "").trim(),
          userEditVersion: 1,
          status: "saved"
        });
        await onTypedNoteCommitted(note);
        return { note };
      }
      case "UPDATE_NOTE_BODY":
        return { note: await repository2.editNoteBody(message.noteId, message.body) };
      case "UPDATE_NOTE_SUBTITLE":
        return { note: await repository2.editNoteSubtitle(message.noteId, message.subtitleContext) };
      case "DELETE_NOTE": {
        await requireCurrentSession(message.sessionId, request);
        const note = await repository2.getNote(message.noteId);
        if (!note || note.sessionId !== message.sessionId) {
          throw new Error("\u6807\u8BB0\u4E0D\u5C5E\u4E8E\u5F53\u524D\u9875\u9762\u4F1A\u8BDD");
        }
        return repository2.deleteSavedNote(message.noteId);
      }
      case "CLEAR_SESSION_NOTES":
        await requireCurrentSession(message.sessionId, request);
        return repository2.clearSessionNotes(message.sessionId);
      case "UNDO_NOTE_ACTION":
        await requireCurrentSession(message.sessionId, request);
        return repository2.undoNoteAction(message.sessionId);
      case "REDO_NOTE_ACTION":
        await requireCurrentSession(message.sessionId, request);
        return repository2.redoNoteAction(message.sessionId);
      default:
        return void 0;
    }
  };
}

// src/core/study-sound-protocol.js
var STUDY_SOUND_EXTENSION_ID = "gbjogdiimlejbeamknhelkkgpfaikdik";
var NOTE_HOLD_PROTOCOL_VERSION = 1;
var NOTE_HOLD_TIMEOUT_MS = 9e4;
function noteHoldMessage(type, { leaseId, tabId, shouldResumeMain = false }) {
  return {
    type,
    protocolVersion: NOTE_HOLD_PROTOCOL_VERSION,
    leaseId,
    tabId,
    timeoutMs: NOTE_HOLD_TIMEOUT_MS,
    shouldResumeMain
  };
}

// src/core/model-config.js
var MODEL_REVISION = "98aa99a0a9db05ae2342309f5096248665f7cba3";
var MODEL_CACHE_NAME = "video-notes-whisper-v1";
var DEFAULT_WHISPER_MODEL_ID = "base-q5_1";
var WHISPER_MODELS = Object.freeze([
  {
    id: "base-q5_1",
    label: "Base \xB7 57 MiB",
    filename: "ggml-base-q5_1.bin",
    size: 59707625,
    sha256: "422f1ae452ade6f30a004d7e5c6a43195e4433bc370bf23fac9cc591f01a8898",
    recommended: true
  },
  {
    id: "small-q5_1",
    label: "Small \xB7 181 MiB",
    filename: "ggml-small-q5_1.bin",
    size: 190085487,
    sha256: "ae85e4a935d7a567bd102fe55afc16bb595bdb618e11b2fc7591bc08120411bb"
  },
  {
    id: "medium-q5_0",
    label: "Medium \xB7 514 MiB",
    filename: "ggml-medium-q5_0.bin",
    size: 539212467,
    sha256: "19fea4b380c3a618ec4723c3eef2eb785ffba0d0538cf43f8f235e7b3b34220f",
    experimental: true
  }
].map((model) => Object.freeze({
  ...model,
  url: `https://huggingface.co/ggerganov/whisper.cpp/resolve/${MODEL_REVISION}/${model.filename}`,
  cacheName: MODEL_CACHE_NAME
})));
function getWhisperModel(modelId) {
  const model = WHISPER_MODELS.find(({ id }) => id === modelId);
  if (!model) throw new Error(`\u672A\u77E5 Whisper \u6A21\u578B\uFF1A${modelId}`);
  return model;
}
var WHISPER_MODEL = getWhisperModel(DEFAULT_WHISPER_MODEL_ID);
var WHISPER_ORIGINS = Object.freeze([
  "https://huggingface.co/*",
  "https://cdn-lfs.hf.co/*",
  "https://*.xethub.hf.co/*"
]);

// src/core/whisper-state.js
function assertModelSwitchAllowed({
  whisperState,
  modelDownloading,
  transcriptionCount,
  recording
}) {
  if (modelDownloading || recording || transcriptionCount > 0 || ["downloading", "recording", "transcribing"].includes(whisperState)) {
    throw new Error("\u8BF7\u7B49\u5F85\u5F53\u524D\u8BED\u97F3\u4EFB\u52A1\u7ED3\u675F\u540E\u518D\u5207\u6362\u6A21\u578B");
  }
}
function createNoteTaskCoordinator() {
  const tails = /* @__PURE__ */ new Map();
  return (noteId, operation) => {
    const previous = tails.get(noteId) ?? Promise.resolve();
    const task = previous.then(operation);
    const tracked = task.then(() => {
    }, () => {
    }).finally(() => {
      if (tails.get(noteId) === tracked) tails.delete(noteId);
    });
    tails.set(noteId, tracked);
    return task;
  };
}

// src/core/whisper-recovery.js
function recoverWhisperState({
  whisperState,
  cachedModelIds,
  selectedModelId,
  processing
}) {
  const modelAvailable = cachedModelIds.includes(selectedModelId);
  const transientStates = /* @__PURE__ */ new Set(["downloading", "recording", "transcribing"]);
  if (processing?.downloading) return { whisperState: "downloading", whisperError: "" };
  if (processing?.recording || processing?.starting || processing?.stopping) {
    return { whisperState: "recording", whisperError: "" };
  }
  if (processing?.transcriptionNoteIds?.length) {
    return { whisperState: "transcribing", whisperError: "" };
  }
  if (transientStates.has(whisperState)) {
    return modelAvailable ? { whisperState: "ready", whisperError: "" } : { whisperState: "error", whisperError: "\u4E0A\u6B21\u672C\u5730\u8BED\u97F3\u4EFB\u52A1\u4E2D\u65AD\uFF0C\u8BF7\u91CD\u65B0\u542F\u7528" };
  }
  if (whisperState === "ready" && !modelAvailable) {
    return { whisperState: "error", whisperError: "\u672C\u5730\u8BED\u97F3\u6A21\u578B\u7F13\u5B58\u5DF2\u4E22\u5931\uFF0C\u8BF7\u91CD\u65B0\u542F\u7528" };
  }
  if (whisperState === "disabled") return { whisperState: "disabled", whisperError: "" };
  if (whisperState === "ready") return { whisperState: "ready", whisperError: "" };
  return { whisperState, whisperError: void 0 };
}

// src/core/whisper-operation.js
function createWhisperOperationLock() {
  let activeOperation = null;
  return {
    async run(task) {
      if (activeOperation) throw new Error("\u6A21\u578B\u64CD\u4F5C\u8FDB\u884C\u4E2D");
      const operation = Promise.resolve().then(task);
      activeOperation = operation;
      try {
        return await operation;
      } finally {
        if (activeOperation === operation) activeOperation = null;
      }
    }
  };
}

// src/core/microphone-navigation.js
var RETURN_TAB_KEY = "microphonePermissionReturnTabId";
function createMicrophoneNavigation({ storageSession, tabs, windows }) {
  return {
    async rememberSource(tab) {
      if (tab?.id >= 0) await storageSession.set({ [RETURN_TAB_KEY]: tab.id });
    },
    async returnToSource() {
      const { [RETURN_TAB_KEY]: returnTabId = -1 } = await storageSession.get({
        [RETURN_TAB_KEY]: -1
      });
      if (returnTabId < 0) return { returned: false };
      try {
        const tab = await tabs.update(returnTabId, { active: true });
        if (tab?.windowId >= 0) await windows.update(tab.windowId, { focused: true });
        return { returned: true };
      } catch {
        return { returned: false };
      } finally {
        await storageSession.remove([RETURN_TAB_KEY]).catch(() => {
        });
      }
    }
  };
}

// src/core/media-permissions.js
var SCREENSHOT_ORIGINS = Object.freeze(["<all_urls>"]);
function canUseMicrophone(savedReady, permissionState) {
  return savedReady === true && permissionState === "granted";
}
function errorMessage(error) {
  return String(error?.message ?? error ?? "\u64CD\u4F5C\u5931\u8D25");
}
function isMicrophonePermissionError(error) {
  return error?.name === "NotAllowedError" || /permission (dismissed|denied)|notallowederror|microphone.*permission/i.test(errorMessage(error));
}
function friendlyMicrophoneError(error) {
  if (isMicrophonePermissionError(error)) {
    return "\u8BF7\u5148\u5728\u4FA7\u680F\u7684\u6743\u9650\u8BBE\u7F6E\u4E2D\u6388\u6743\u9EA6\u514B\u98CE";
  }
  return errorMessage(error);
}
function friendlyCaptureError(error) {
  const message = errorMessage(error);
  if (/<all_urls>|activeTab.*permission|permission.*activeTab/i.test(message)) {
    return "\u8BF7\u5728\u4FA7\u680F\u7684\u6743\u9650\u8BBE\u7F6E\u4E2D\u542F\u7528\u64AD\u653E\u5668\u622A\u56FE";
  }
  return message;
}

// src/core/site-adapter.js
var YOUTUBE_HOSTS = /* @__PURE__ */ new Set(["youtube.com", "www.youtube.com", "m.youtube.com"]);
var BILIBILI_HOSTS = /* @__PURE__ */ new Set(["bilibili.com", "www.bilibili.com"]);
function positiveInteger(value, fallback = 1) {
  const number = Number.parseInt(value ?? "", 10);
  return Number.isInteger(number) && number > 0 ? number : fallback;
}
function parseVideoContext(url, title = "\u672A\u547D\u540D\u89C6\u9891") {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return null;
  }
  if (YOUTUBE_HOSTS.has(parsed.hostname) && parsed.pathname === "/watch") {
    const videoId = parsed.searchParams.get("v")?.trim();
    if (!videoId) return null;
    return {
      platform: "youtube",
      sessionId: `youtube:${videoId}`,
      videoId,
      part: 1,
      title,
      canonicalUrl: `https://www.youtube.com/watch?v=${encodeURIComponent(videoId)}`
    };
  }
  if (BILIBILI_HOSTS.has(parsed.hostname)) {
    const match = parsed.pathname.match(/^\/video\/(BV[0-9A-Za-z]+)/i);
    if (!match) return null;
    const videoId = match[1];
    const part = positiveInteger(parsed.searchParams.get("p"));
    return {
      platform: "bilibili",
      sessionId: `bilibili:${videoId}:${part}`,
      videoId,
      part,
      title,
      canonicalUrl: `https://www.bilibili.com/video/${videoId}?p=${part}`
    };
  }
  return null;
}

// src/core/sidepanel-scope.js
function contextChangedSenderTab(sender) {
  return Number.isInteger(sender?.tab?.id) ? sender.tab : null;
}
function validContextId(value) {
  return Number.isInteger(value) && value >= 0;
}
function activeContextChangedMessage(tabId, windowId) {
  if (!validContextId(tabId) || !validContextId(windowId)) return null;
  return { type: "ACTIVE_CONTEXT_CHANGED", tabId, windowId };
}
function sidePanelContextForSender(sender, contexts, fallbackTab = null) {
  const context = contexts.find((candidate) => candidate.contextType === "SIDE_PANEL" && candidate.documentId === sender?.documentId);
  const contextWindowId = validContextId(context?.windowId) ? context.windowId : null;
  const fallbackMatchesWindow = contextWindowId === null || fallbackTab?.windowId === contextWindowId;
  return {
    tabId: validContextId(context?.tabId) ? context.tabId : fallbackMatchesWindow && validContextId(fallbackTab?.id) ? fallbackTab.id : null,
    windowId: contextWindowId ?? (validContextId(fallbackTab?.windowId) ? fallbackTab.windowId : null)
  };
}
function createActiveTabActivationHandler({
  tabs,
  runtime,
  configureSidePanelForTab: configureSidePanelForTab2,
  onError = () => {
  }
}) {
  return async ({ tabId, windowId }) => {
    let tab;
    try {
      tab = await tabs.get(tabId);
      await configureSidePanelForTab2(tab);
      const message = activeContextChangedMessage(tabId, windowId);
      if (message) await runtime.sendMessage(message).catch(() => {
      });
    } catch (error) {
      onError(tab ?? { id: tabId }, error);
    }
  };
}
function createSidePanelContextResolver({ runtime, tabs }) {
  return async (sender) => {
    const contexts = await runtime.getContexts({ contextTypes: ["SIDE_PANEL"] });
    let context = sidePanelContextForSender(sender, contexts);
    let fallbackTab = null;
    if (context.tabId === null) {
      const query = context.windowId === null ? { active: true, lastFocusedWindow: true } : { active: true, windowId: context.windowId };
      [fallbackTab] = await tabs.query(query);
    } else if (context.windowId === null) {
      fallbackTab = await tabs.get(context.tabId);
    }
    if (fallbackTab) context = sidePanelContextForSender(sender, contexts, fallbackTab);
    if (context.tabId === null || context.windowId === null) {
      throw new Error("\u65E0\u6CD5\u786E\u5B9A\u4FA7\u680F\u6240\u5C5E\u6807\u7B7E\u9875");
    }
    return { context, contexts, fallbackTab };
  };
}
function sidePanelMessageForTabUpdate(tabId, changeInfo, tab) {
  if (!Number.isInteger(tabId) || changeInfo?.status !== "complete" || tab?.active !== true || !tab.url || !parseVideoContext(tab.url)) {
    return null;
  }
  return { type: "TAB_LOAD_COMPLETE", tabId };
}
function sidePanelTabIdForSender(sender, contexts, fallbackTabId = null) {
  const context = contexts.find((candidate) => candidate.contextType === "SIDE_PANEL" && candidate.documentId === sender?.documentId && Number.isInteger(candidate.tabId) && candidate.tabId >= 0);
  return context?.tabId ?? (Number.isInteger(fallbackTabId) && fallbackTabId >= 0 ? fallbackTabId : null);
}
function sidePanelRequestTabIdForSender(sender, contexts, fallbackTabId, requestedTabId) {
  const tabId = sidePanelTabIdForSender(sender, contexts, fallbackTabId);
  if (tabId === null) {
    throw new Error("\u65E0\u6CD5\u786E\u5B9A\u4FA7\u680F\u6240\u5C5E\u6807\u7B7E\u9875");
  }
  if (!Number.isInteger(requestedTabId) || requestedTabId !== tabId) {
    throw new Error("\u4FA7\u680F\u6240\u5C5E\u6807\u7B7E\u9875\u5DF2\u53D8\u5316");
  }
  return tabId;
}
function sidePanelOptionsForTab(tab) {
  if (!Number.isInteger(tab?.id)) throw new Error("\u7F3A\u5C11\u6709\u6548 tabId");
  const supported = Boolean(tab.url && parseVideoContext(tab.url));
  return supported ? { tabId: tab.id, path: "sidepanel.html", enabled: true } : { tabId: tab.id, enabled: false };
}

// src/core/tab-messaging.js
function isMissingTabReceiverError(error) {
  return String(error?.message ?? error).includes("Receiving end does not exist");
}
function isBlockedTabAccessError(error) {
  return String(error?.message ?? error).trim() === "Blocked";
}
function createTabMessenger({ tabs, scripting, contentScript = "content.js" }) {
  const pendingInjections = /* @__PURE__ */ new Map();
  async function ensureContentScript(tabId) {
    let injection = pendingInjections.get(tabId);
    if (!injection) {
      injection = Promise.resolve().then(() => scripting.executeScript({
        target: { tabId },
        files: [contentScript]
      }));
      pendingInjections.set(tabId, injection);
    }
    try {
      await injection;
    } finally {
      if (pendingInjections.get(tabId) === injection) pendingInjections.delete(tabId);
    }
  }
  return {
    async send(tabId, message) {
      try {
        return await tabs.sendMessage(tabId, message);
      } catch (error) {
        if (!isMissingTabReceiverError(error)) throw error;
        try {
          await ensureContentScript(tabId);
        } catch (injectionError) {
          if (isBlockedTabAccessError(injectionError)) {
            throw new Error("Edge \u5DF2\u6682\u505C\u5F53\u524D\u7AD9\u70B9\u7684\u6269\u5C55\uFF0C\u8BF7\u5728\u5DE5\u5177\u680F\u6269\u5C55\u83DC\u5355\u4E2D\u5F00\u542F\u201C\u5141\u8BB8\u5728\u5F53\u524D\u7F51\u7AD9\u4F7F\u7528\u6269\u5C55\u201D\uFF0C\u7136\u540E\u5237\u65B0\u9875\u9762");
          }
          throw injectionError;
        }
        return tabs.sendMessage(tabId, message);
      }
    }
  };
}

// src/background.js
var repository = new VideoNotesRepository();
var tabMessenger = createTabMessenger({
  tabs: chrome.tabs,
  scripting: chrome.scripting
});
var microphoneNavigation = createMicrophoneNavigation({
  storageSession: chrome.storage.session,
  tabs: chrome.tabs,
  windows: chrome.windows
});
var heartbeatTimers = /* @__PURE__ */ new Map();
var cancelPendingVoice = false;
var offscreenCreationPromise = null;
var voiceStartPromise = null;
var voiceStopPromise = null;
var activeVoiceNote = null;
var whisperRecoveryPromise = Promise.resolve();
var microphonePermissionPagePromise = null;
var microphonePermissionTabId = null;
var whisperModelOperationLock = createWhisperOperationLock();
var coordinateNoteTranscription = createNoteTaskCoordinator();
var noteHistoryCommandRouter = createNoteHistoryCommandRouter({
  repository,
  getCurrentContext: currentPageContext,
  onTypedNoteCommitted: releaseMarker
});
var resolveSidePanelContext = createSidePanelContextResolver({
  runtime: chrome.runtime,
  tabs: chrome.tabs
});
var handleActiveTabActivation = createActiveTabActivationHandler({
  runtime: chrome.runtime,
  tabs: chrome.tabs,
  configureSidePanelForTab,
  onError: logSidePanelConfigurationError
});
function logSidePanelConfigurationError(tab, error) {
  console.warn("\u914D\u7F6E\u6807\u7B7E\u9875\u4FA7\u680F\u5931\u8D25", tab?.id, error);
}
async function configureSidePanelForTab(tab) {
  try {
    await chrome.sidePanel.setOptions(sidePanelOptionsForTab(tab));
  } catch (error) {
    logSidePanelConfigurationError(tab, error);
  }
}
async function configureExistingSidePanels() {
  let tabs;
  try {
    tabs = await chrome.tabs.query({});
  } catch (error) {
    console.warn("\u67E5\u8BE2\u73B0\u6709\u6807\u7B7E\u9875\u4EE5\u914D\u7F6E\u4FA7\u680F\u5931\u8D25", error);
    return;
  }
  await Promise.all(tabs.map((tab) => configureSidePanelForTab(tab)));
}
function notifyActiveContextChanged(tabId, windowId) {
  const message = activeContextChangedMessage(tabId, windowId);
  if (!message) return;
  void chrome.runtime.sendMessage(message).catch(() => {
  });
}
chrome.runtime.onInstalled.addListener(() => {
  void (async () => {
    try {
      await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
      const settings = await chrome.storage.local.get([
        "shortcutCode",
        "whisperState",
        "whisperSelectedModel",
        "whisperModel"
      ]);
      await chrome.storage.local.set({
        shortcutCode: settings.shortcutCode ?? "AltRight",
        whisperState: settings.whisperState ?? "disabled",
        whisperSelectedModel: getWhisperModel(
          settings.whisperSelectedModel || settings.whisperModel || DEFAULT_WHISPER_MODEL_ID
        ).id
      });
      await configureExistingSidePanels();
    } catch (error) {
      console.warn("\u521D\u59CB\u5316\u4FA7\u680F\u5931\u8D25", error);
    }
  })();
});
chrome.runtime.onStartup.addListener(() => {
  void (async () => {
    try {
      await chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true });
      await configureExistingSidePanels();
    } catch (error) {
      console.warn("\u542F\u52A8\u65F6\u914D\u7F6E\u4FA7\u680F\u5931\u8D25", error);
    }
  })();
});
chrome.tabs.onCreated.addListener((tab) => {
  void configureSidePanelForTab(tab);
});
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.url || changeInfo.status === "complete") {
    void configureSidePanelForTab({ ...tab, id: tabId });
  }
  const refreshMessage = sidePanelMessageForTabUpdate(tabId, changeInfo, tab);
  if (refreshMessage) {
    void chrome.runtime.sendMessage(refreshMessage).catch(() => {
    });
  }
});
chrome.tabs.onActivated.addListener((activeInfo) => {
  void handleActiveTabActivation(activeInfo);
});
async function activeSupportedTab() {
  const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (!tab?.id) throw new Error("\u6CA1\u6709\u627E\u5230\u5F53\u524D\u6807\u7B7E\u9875");
  return tab;
}
async function targetTab(sender, requestedTabId) {
  if (sender.tab?.id) return sender.tab;
  if (Number.isInteger(requestedTabId)) return chrome.tabs.get(requestedTabId);
  return activeSupportedTab();
}
async function openMicrophonePermissionPage(returnTab) {
  await microphoneNavigation.rememberSource(returnTab);
  if (!microphonePermissionPagePromise) {
    microphonePermissionPagePromise = (async () => {
      const url = chrome.runtime.getURL("microphone-permission.html");
      if (microphonePermissionTabId !== null) {
        try {
          return await chrome.tabs.update(microphonePermissionTabId, { active: true });
        } catch {
          microphonePermissionTabId = null;
        }
      }
      const [existing] = await chrome.runtime.getContexts({
        contextTypes: ["TAB"],
        documentUrls: [url]
      });
      if (existing?.tabId >= 0) {
        microphonePermissionTabId = existing.tabId;
        await chrome.tabs.update(existing.tabId, { active: true });
        if (existing.windowId >= 0) {
          await chrome.windows.update(existing.windowId, { focused: true }).catch(() => {
          });
        }
        return { tabId: existing.tabId };
      }
      const tab = await chrome.tabs.create({ url, active: true });
      microphonePermissionTabId = tab.id ?? null;
      return tab;
    })().finally(() => {
      microphonePermissionPagePromise = null;
    });
  }
  return microphonePermissionPagePromise;
}
async function sendToTab(tabId, message) {
  const response = await tabMessenger.send(tabId, message);
  if (!response?.ok) throw new Error(response?.error ?? "\u89C6\u9891\u9875\u9762\u6CA1\u6709\u54CD\u5E94");
  return response;
}
async function ensureOffscreenDocument() {
  if (await chrome.offscreen.hasDocument()) return;
  if (!offscreenCreationPromise) {
    offscreenCreationPromise = chrome.offscreen.createDocument({
      url: "offscreen.html",
      reasons: ["USER_MEDIA", "WORKERS", "BLOBS"],
      justification: "\u5728\u672C\u673A\u5F55\u97F3\u3001\u8FD0\u884C Whisper Worker\uFF0C\u5E76\u751F\u6210\u53EF\u4E0B\u8F7D\u7684 ZIP \u6587\u4EF6"
    }).finally(() => {
      offscreenCreationPromise = null;
    });
  }
  await offscreenCreationPromise;
}
async function sendToOffscreen(message) {
  await ensureOffscreenDocument();
  const response = await chrome.runtime.sendMessage({ ...message, target: "offscreen" });
  if (!response?.ok) throw new Error(response?.error ?? "\u672C\u5730\u5904\u7406\u9875\u9762\u6CA1\u6709\u54CD\u5E94");
  return response;
}
async function enqueueTranscription(noteId, modelId, source) {
  getWhisperModel(modelId);
  if (!["automatic", "manual"].includes(source)) throw new Error("\u672A\u77E5\u8F6C\u5199\u6765\u6E90");
  await sendToOffscreen({
    type: "TRANSCRIBE_NOTE",
    noteId,
    modelId,
    source
  });
}
async function markTranscriptionFailure(noteId, error) {
  const warning = `\u8F6C\u5199\u5931\u8D25\uFF1A${error.message}`;
  await repository.updateNote(noteId, (note) => ({
    ...note,
    pendingTranscription: null,
    transcriptionStatus: "error",
    warnings: note.warnings?.includes(warning) ? note.warnings : [...note.warnings ?? [], warning],
    updatedAt: Date.now()
  })).catch(() => {
  });
}
async function queueTranscription(noteId, modelId, source) {
  getWhisperModel(modelId);
  if (!["automatic", "manual"].includes(source)) throw new Error("\u672A\u77E5\u8F6C\u5199\u6765\u6E90");
  const pendingTranscription = { modelId, source, queuedAt: Date.now() };
  await repository.updateNote(noteId, (note) => ({
    ...note,
    transcriptionStatus: "pending",
    pendingTranscription,
    updatedAt: Date.now()
  }));
  void enqueueTranscription(noteId, modelId, source).catch((error) => markTranscriptionFailure(noteId, error));
}
async function recoverTransientWhisperState() {
  const settings = await chrome.storage.local.get({
    whisperState: "disabled",
    whisperSelectedModel: "",
    whisperModel: ""
  });
  let processing = null;
  if (await chrome.offscreen.hasDocument()) {
    processing = await sendToOffscreen({ type: "GET_PROCESSING_STATE" }).catch(() => null);
  }
  const cacheStatus = await sendToOffscreen({ type: "GET_MODEL_CACHE_STATUS" });
  const cachedModelIds = cacheStatus.cachedModelIds;
  const selectedModelId = getWhisperModel(
    settings.whisperSelectedModel || settings.whisperModel || DEFAULT_WHISPER_MODEL_ID
  ).id;
  const { whisperState, whisperError } = recoverWhisperState({
    whisperState: settings.whisperState,
    cachedModelIds,
    selectedModelId,
    processing
  });
  const recovered = {
    whisperState,
    whisperSelectedModel: selectedModelId
  };
  if (whisperError !== void 0) recovered.whisperError = whisperError;
  await chrome.storage.local.set(recovered);
  if (processing?.downloading) return;
  await chrome.permissions.remove({ origins: WHISPER_ORIGINS }).catch(() => false);
  const activeNoteIds = new Set(processing?.transcriptionNoteIds ?? []);
  const pending = (await repository.listPendingTranscriptions()).filter((note) => !activeNoteIds.has(note.id));
  if (pending.length === 0) return;
  for (const note of pending) {
    let pendingTranscription = note.pendingTranscription;
    if (!pendingTranscription) {
      pendingTranscription = {
        modelId: selectedModelId,
        source: (note.transcriptionRuns?.length ?? 0) > 0 ? "manual" : "automatic",
        queuedAt: Date.now()
      };
      await repository.updateNote(note.id, (current) => ({
        ...current,
        transcriptionStatus: "pending",
        pendingTranscription,
        updatedAt: Date.now()
      }));
    }
    if (!cachedModelIds.includes(pendingTranscription.modelId)) {
      await markTranscriptionFailure(note.id, new Error("\u5F85\u8F6C\u5199\u6A21\u578B\u7F13\u5B58\u5DF2\u4E22\u5931\uFF0C\u8BF7\u91CD\u65B0\u4E0B\u8F7D"));
      continue;
    }
    void enqueueTranscription(
      note.id,
      pendingTranscription.modelId,
      pendingTranscription.source
    ).catch((error) => markTranscriptionFailure(note.id, error));
  }
}
whisperRecoveryPromise = recoverTransientWhisperState().catch(async (error) => {
  await chrome.storage.local.set({ whisperState: "error", whisperError: error.message });
});
async function cropVisiblePlayer(tab, snapshot) {
  const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
  const sourceBlob = await (await fetch(dataUrl)).blob();
  const bitmap = await createImageBitmap(sourceBlob);
  try {
    const crop = computeScreenshotCrop(
      snapshot.rect,
      snapshot.viewport,
      { width: bitmap.width, height: bitmap.height },
      1600
    );
    const canvas = new OffscreenCanvas(crop.outputWidth, crop.outputHeight);
    const context = canvas.getContext("2d", { alpha: false });
    context.drawImage(
      bitmap,
      crop.sx,
      crop.sy,
      crop.sw,
      crop.sh,
      0,
      0,
      crop.outputWidth,
      crop.outputHeight
    );
    return await canvas.convertToBlob({ type: "image/webp", quality: 0.85 });
  } finally {
    bitmap.close();
  }
}
async function beginMarker(tab, inputType, { beforePause, onPrepared } = {}) {
  const markerId = crypto.randomUUID();
  const snapshot = await sendToTab(tab.id, {
    type: "PREPARE_MARKER",
    markerId,
    deferPause: Boolean(beforePause)
  });
  const now = Date.now();
  const session = {
    id: snapshot.context.sessionId,
    platform: snapshot.context.platform,
    videoId: snapshot.context.videoId,
    part: snapshot.context.part,
    title: snapshot.context.title,
    canonicalUrl: snapshot.context.canonicalUrl,
    createdAt: now,
    updatedAt: now
  };
  const note = {
    id: markerId,
    sessionId: session.id,
    tabId: tab.id,
    seconds: snapshot.seconds,
    jumpUrl: snapshot.jumpUrl,
    inputType,
    body: "",
    transcriptionStatus: inputType === "voice" ? "pending" : "none",
    transcriptCandidate: "",
    transcriptionModelId: "",
    transcriptionRuns: [],
    pendingTranscription: null,
    subtitleContext: snapshot.subtitleContext,
    screenshotKey: "",
    audioKey: "",
    warnings: [],
    wasPlaying: snapshot.wasPlaying,
    studySoundLinked: false,
    userEditVersion: 0,
    status: inputType === "voice" ? "recording" : "draft",
    createdAt: now,
    updatedAt: now
  };
  if (beforePause) {
    await beforePause(note);
    await sendToTab(tab.id, {
      type: "ACTIVATE_MARKER",
      markerId,
      wasPlaying: note.wasPlaying
    });
  }
  const preparedTask = onPrepared ? Promise.resolve(onPrepared(note)) : Promise.resolve();
  const existingSession = await repository.getSession(session.id);
  if (existingSession) session.createdAt = existingSession.createdAt;
  await repository.putSession(session);
  try {
    const screenshot = await cropVisiblePlayer(tab, snapshot);
    note.screenshotKey = `images/${markerId}`;
    await repository.putAsset(note.screenshotKey, screenshot);
  } catch (error) {
    note.warnings.push(`\u622A\u56FE\u5931\u8D25\uFF1A${friendlyCaptureError(error)}`);
  }
  await repository.putNote(note);
  await preparedTask;
  return { session, note };
}
async function releaseMarker(note, shouldNotifyStudySound = false) {
  const shouldCoordinate = shouldNotifyStudySound && note.studySoundLinked === true;
  let externalReleased = false;
  if (shouldCoordinate) {
    let shouldResumeMain = false;
    try {
      const eligibility = await sendToTab(note.tabId, {
        type: "GET_MARKER_RESUME_ELIGIBILITY",
        markerId: note.id
      });
      shouldResumeMain = eligibility.shouldResume === true;
    } catch {
      shouldResumeMain = false;
    }
    externalReleased = await releaseStudySoundHold(note, shouldResumeMain);
  }
  try {
    const response = await sendToTab(note.tabId, {
      type: "RELEASE_MARKER",
      markerId: note.id,
      allowResume: !externalReleased
    });
    return response.resumed;
  } catch {
    return false;
  }
}
async function cancelNote(noteId, fallbackNote = null) {
  const storedNote = await repository.getNote(noteId);
  const note = storedNote && fallbackNote ? {
    ...fallbackNote,
    ...storedNote,
    screenshotKey: fallbackNote.screenshotKey || storedNote.screenshotKey,
    audioKey: fallbackNote.audioKey || storedNote.audioKey
  } : storedNote ?? fallbackNote;
  if (!note) return;
  if (storedNote) await repository.deleteNote(note.id);
  if (note.screenshotKey) await repository.deleteAsset(note.screenshotKey);
  if (note.audioKey) await repository.deleteAsset(note.audioKey);
  await releaseMarker(note, note.inputType === "voice");
}
async function externalStudySound(message) {
  return chrome.runtime.sendMessage(STUDY_SOUND_EXTENSION_ID, message);
}
async function acquireStudySoundHold(note) {
  try {
    const response = await externalStudySound(
      noteHoldMessage("NOTE_HOLD_ACQUIRE", {
        leaseId: note.id,
        tabId: note.tabId,
        shouldResumeMain: note.wasPlaying
      })
    );
    if (!response?.ok || response.protocolVersion !== 1) throw new Error("\u534F\u8BAE\u4E0D\u517C\u5BB9");
    const timer = setInterval(() => {
      void externalStudySound(
        noteHoldMessage("NOTE_HOLD_HEARTBEAT", { leaseId: note.id, tabId: note.tabId })
      ).catch(() => {
      });
    }, 3e4);
    heartbeatTimers.set(note.id, timer);
    note.studySoundLinked = true;
    return true;
  } catch {
    note.studySoundLinked = false;
    const { studySoundWarningShown = false } = await chrome.storage.local.get(
      "studySoundWarningShown"
    );
    if (!studySoundWarningShown) {
      note.warnings.push("\u80CC\u666F\u97F3\u672A\u8054\u52A8\u9759\u97F3");
      await chrome.storage.local.set({ studySoundWarningShown: true });
    }
    return false;
  }
}
async function releaseStudySoundHold(note, shouldResumeMain) {
  clearInterval(heartbeatTimers.get(note.id));
  heartbeatTimers.delete(note.id);
  try {
    const response = await externalStudySound(
      noteHoldMessage("NOTE_HOLD_RELEASE", {
        leaseId: note.id,
        tabId: note.tabId,
        shouldResumeMain
      })
    );
    return response?.ok === true && response.protocolVersion === 1;
  } catch {
    return false;
  }
}
async function startVoice(tab) {
  if (voiceStartPromise || voiceStopPromise) throw new Error("\u5F55\u97F3\u6B63\u5728\u542F\u52A8\u6216\u4FDD\u5B58\uFF0C\u8BF7\u7A0D\u5019");
  voiceStartPromise = startVoiceUnlocked(tab);
  try {
    return await voiceStartPromise;
  } finally {
    voiceStartPromise = null;
  }
}
async function startVoiceUnlocked(tab) {
  cancelPendingVoice = false;
  const { microphoneReady = false } = await chrome.storage.local.get({ microphoneReady: false });
  if (!microphoneReady) {
    await openMicrophonePermissionPage(tab);
    throw new Error("\u8BF7\u5728\u65B0\u9875\u9762\u5B8C\u6210\u9EA6\u514B\u98CE\u6388\u6743");
  }
  const microphonePermission = await sendToOffscreen({ type: "GET_MICROPHONE_PERMISSION" });
  if (!canUseMicrophone(microphoneReady, microphonePermission.state)) {
    await chrome.storage.local.set({ microphoneReady: false });
    await openMicrophonePermissionPage(tab);
    throw new Error("\u8BF7\u5728\u65B0\u9875\u9762\u5B8C\u6210\u9EA6\u514B\u98CE\u6388\u6743");
  }
  const recording = await sendToOffscreen({ type: "GET_RECORDING_STATE" });
  if (recording.recording) throw new Error("\u5DF2\u6709\u5F55\u97F3\u6B63\u5728\u8FDB\u884C");
  let preparedNote = null;
  try {
    const { note, session } = await beginMarker(tab, "voice", {
      beforePause(noteToPrepare) {
        preparedNote = noteToPrepare;
        activeVoiceNote = noteToPrepare;
        return acquireStudySoundHold(noteToPrepare);
      },
      onPrepared(noteToPrepare) {
        preparedNote = noteToPrepare;
        return sendToOffscreen({ type: "START_RECORDING", noteId: noteToPrepare.id });
      }
    });
    if (cancelPendingVoice) {
      cancelPendingVoice = false;
      await stopVoice("sidepanel-closed");
      return { note, session, canceled: true };
    }
    void chrome.runtime.sendMessage({
      type: "VOICE_STATE_CHANGED",
      recording: true,
      noteId: note.id,
      tabId: note.tabId
    }).catch(() => {
    });
    return { note, session };
  } catch (error) {
    const permissionError = isMicrophonePermissionError(error);
    if (permissionError) {
      await chrome.storage.local.set({ microphoneReady: false });
    }
    const state = await sendToOffscreen({ type: "GET_RECORDING_STATE" }).catch(() => ({}));
    const noteId = state.noteId ?? preparedNote?.id;
    if (state.recording) await sendToOffscreen({ type: "ABORT_RECORDING" }).catch(() => {
    });
    if (noteId) await cancelNote(noteId, preparedNote);
    activeVoiceNote = null;
    if (permissionError) await openMicrophonePermissionPage(tab).catch(() => {
    });
    throw new Error(friendlyMicrophoneError(error));
  }
}
async function stopVoice(reason) {
  if (voiceStopPromise) return voiceStopPromise;
  voiceStopPromise = stopVoiceUnlocked(reason);
  try {
    return await voiceStopPromise;
  } finally {
    voiceStopPromise = null;
  }
}
async function stopVoiceUnlocked(reason) {
  const fallbackNote = activeVoiceNote;
  let result;
  try {
    result = await sendToOffscreen({ type: "STOP_RECORDING", reason });
  } catch (error) {
    if (fallbackNote) {
      const note2 = await repository.getNote(fallbackNote.id) ?? fallbackNote;
      const warning = `\u5F55\u97F3\u4FDD\u5B58\u5931\u8D25\uFF1A${error.message}`;
      const savedNote = await repository.commitSavedNote(note2.id, {
        status: "saved",
        transcriptionStatus: "error",
        warnings: [...note2.warnings ?? [], warning]
      });
      await releaseMarker(savedNote, true);
      await finishVoiceUi(savedNote);
    }
    activeVoiceNote = null;
    throw error;
  }
  const note = await repository.getNote(result.noteId);
  if (!note) throw new Error("\u5F55\u97F3\u5BF9\u5E94\u7684\u6807\u8BB0\u5DF2\u4E22\u5931");
  await releaseMarker(note, true);
  activeVoiceNote = null;
  await finishVoiceUi(note);
  if (result.whisperReady) {
    const { whisperSelectedModel = "" } = await chrome.storage.local.get({
      whisperSelectedModel: ""
    });
    await queueTranscription(
      note.id,
      getWhisperModel(whisperSelectedModel || DEFAULT_WHISPER_MODEL_ID).id,
      "automatic"
    );
  }
  return { noteId: note.id };
}
async function finishVoiceUi(note) {
  void sendToTab(note.tabId, {
    type: "FORCE_STOP_RECORDING",
    reason: "recording-ended"
  }).catch(() => {
  });
  void chrome.runtime.sendMessage({
    type: "VOICE_STATE_CHANGED",
    recording: false,
    noteId: note.id,
    tabId: note.tabId
  }).catch(() => {
  });
}
chrome.tabs.onRemoved.addListener((tabId) => {
  void (async () => {
    const exists = await chrome.offscreen.hasDocument();
    const recording = exists ? await sendToOffscreen({ type: "GET_RECORDING_STATE" }).catch(() => null) : null;
    let note = activeVoiceNote?.tabId === tabId ? activeVoiceNote : null;
    if (!note && recording?.noteId) {
      const stored = await repository.getNote(recording.noteId);
      if (stored?.tabId === tabId) note = stored;
    }
    if (!note) return;
    if (recording?.recording || recording?.stopping) {
      await stopVoice("tab-closed");
      return;
    }
    if (recording?.starting) await sendToOffscreen({ type: "ABORT_RECORDING" }).catch(() => {
    });
    await cancelNote(note.id, note);
    activeVoiceNote = null;
  })().catch(() => {
  });
});
async function currentPageContext({ sender, tabId }) {
  const tab = await targetTab(sender, tabId);
  const response = await sendToTab(tab.id, { type: "GET_PAGE_CONTEXT" });
  return response.context ?? null;
}
async function enableWhisper(modelId = DEFAULT_WHISPER_MODEL_ID) {
  return whisperModelOperationLock.run(() => enableWhisperCore(modelId));
}
async function enableWhisperCore(modelId) {
  await whisperRecoveryPromise;
  const model = getWhisperModel(modelId);
  const processing = await sendToOffscreen({ type: "GET_PROCESSING_STATE" });
  assertModelSwitchAllowed({
    whisperState: processing.downloading ? "downloading" : processing.recording || processing.starting || processing.stopping ? "recording" : processing.transcriptionNoteIds.length > 0 ? "transcribing" : "ready",
    modelDownloading: processing.downloading,
    transcriptionCount: processing.transcriptionNoteIds.length,
    recording: processing.recording || processing.starting || processing.stopping
  });
  try {
    await chrome.storage.local.set({ whisperState: "downloading", whisperError: "" });
    const result = await sendToOffscreen({ type: "DOWNLOAD_MODEL", modelId: model.id });
    await chrome.storage.local.set({ whisperState: "ready", whisperSelectedModel: result.model });
    return result;
  } catch (error) {
    await chrome.storage.local.set({ whisperState: "error", whisperError: error.message });
    throw error;
  } finally {
    await chrome.permissions.remove({ origins: WHISPER_ORIGINS }).catch(() => false);
  }
}
async function selectWhisperModel(modelId) {
  return whisperModelOperationLock.run(() => selectWhisperModelCore(modelId));
}
async function selectWhisperModelCore(modelId) {
  await whisperRecoveryPromise;
  getWhisperModel(modelId);
  const processing = await sendToOffscreen({ type: "GET_PROCESSING_STATE" });
  assertModelSwitchAllowed({
    whisperState: processing.downloading ? "downloading" : processing.recording || processing.starting || processing.stopping ? "recording" : processing.transcriptionNoteIds.length > 0 ? "transcribing" : "ready",
    modelDownloading: processing.downloading,
    transcriptionCount: processing.transcriptionNoteIds.length,
    recording: processing.recording || processing.starting || processing.stopping
  });
  return sendToOffscreen({ type: "SELECT_WHISPER_MODEL", modelId });
}
var PAGE_SCOPED_NOTE_HISTORY_COMMANDS = /* @__PURE__ */ new Set([
  "GET_ACTIVE_STATE",
  "DELETE_NOTE",
  "CLEAR_SESSION_NOTES",
  "UNDO_NOTE_ACTION",
  "REDO_NOTE_ACTION"
]);
async function noteHistoryRequest(message, sender) {
  if (!PAGE_SCOPED_NOTE_HISTORY_COMMANDS.has(message.type)) {
    return { sender, tabId: message.tabId };
  }
  const { context, contexts, fallbackTab } = await resolveSidePanelContext(sender);
  return {
    sender,
    tabId: sidePanelRequestTabIdForSender(
      sender,
      contexts,
      fallbackTab?.id ?? context.tabId,
      message.tabId
    )
  };
}
async function handleMessage(message, sender) {
  if (isNoteHistoryCommand(message.type)) {
    const request = await noteHistoryRequest(message, sender);
    return noteHistoryCommandRouter(message, request);
  }
  switch (message.type) {
    case "OFFSCREEN_STORAGE_GET":
      assertOffscreenSender(sender);
      return { values: await chrome.storage.local.get(message.keys) };
    case "OFFSCREEN_STORAGE_SET":
      assertOffscreenSender(sender);
      await chrome.storage.local.set(message.values);
      return {};
    case "OFFSCREEN_STORAGE_REMOVE":
      assertOffscreenSender(sender);
      await chrome.storage.local.remove(message.keys);
      return {};
    case "OFFSCREEN_DOWNLOAD":
      assertOffscreenSender(sender);
      return {
        downloadId: await chrome.downloads.download({
          url: message.url,
          filename: message.filename,
          saveAs: true
        })
      };
    case "GET_SIDEPANEL_CONTEXT": {
      const { context } = await resolveSidePanelContext(sender);
      return context;
    }
    case "BEGIN_TYPED_NOTE": {
      const tab = await targetTab(sender);
      return beginMarker(tab, "typed");
    }
    case "CANCEL_NOTE":
      await cancelNote(message.noteId);
      return {};
    case "VOICE_START_REQUEST": {
      const tab = await targetTab(sender);
      return startVoice(tab);
    }
    case "OPEN_MICROPHONE_PERMISSION_PAGE": {
      const tab = await targetTab(sender);
      return openMicrophonePermissionPage(tab);
    }
    case "MICROPHONE_PERMISSION_GRANTED":
      if (sender.url !== chrome.runtime.getURL("microphone-permission.html")) {
        throw new Error("\u9EA6\u514B\u98CE\u6388\u6743\u5B8C\u6210\u6D88\u606F\u6765\u6E90\u65E0\u6548");
      }
      return microphoneNavigation.returnToSource();
    case "VOICE_STOP_REQUEST":
      return stopVoice(message.reason);
    case "CANCEL_PENDING_VOICE": {
      cancelPendingVoice = true;
      const state = await sendToOffscreen({ type: "GET_RECORDING_STATE" });
      if (state.recording) await stopVoice(message.reason ?? "sidepanel-closed");
      else if (state.starting) await sendToOffscreen({ type: "ABORT_RECORDING" });
      return {};
    }
    case "RECORDING_TIMEOUT":
      if (sender.url !== chrome.runtime.getURL("offscreen.html")) {
        throw new Error("\u5F55\u97F3\u8D85\u65F6\u6D88\u606F\u6765\u6E90\u65E0\u6548");
      }
      return stopVoice("timeout");
    case "RETRANSCRIBE_NOTE": {
      await whisperRecoveryPromise;
      return coordinateNoteTranscription(message.noteId, async () => {
        const note = await repository.getNote(message.noteId);
        if (note?.inputType !== "voice" || !note.audioKey) {
          throw new Error("\u8BE5\u6807\u8BB0\u6CA1\u6709\u53EF\u91CD\u65B0\u8F6C\u5199\u7684\u539F\u59CB\u5F55\u97F3");
        }
        if (note.pendingTranscription || ["pending", "transcribing"].includes(note.transcriptionStatus)) {
          throw new Error("\u8BE5\u6807\u8BB0\u6B63\u5728\u8F6C\u5199\uFF0C\u8BF7\u7B49\u5F85\u5B8C\u6210\u540E\u518D\u8BD5");
        }
        const processing = await sendToOffscreen({ type: "GET_PROCESSING_STATE" });
        if (processing.downloading || processing.recording || processing.starting || processing.stopping || processing.transcriptionNoteIds.length > 0) {
          throw new Error("\u8BF7\u7B49\u5F85\u5F53\u524D\u8BED\u97F3\u4EFB\u52A1\u7ED3\u675F\u540E\u518D\u91CD\u65B0\u8F6C\u5199");
        }
        const [settings, cacheStatus] = await Promise.all([
          chrome.storage.local.get({ whisperSelectedModel: "" }),
          sendToOffscreen({ type: "GET_MODEL_CACHE_STATUS" })
        ]);
        const modelId = getWhisperModel(
          settings.whisperSelectedModel || DEFAULT_WHISPER_MODEL_ID
        ).id;
        if (!cacheStatus.cachedModelIds.includes(modelId)) {
          throw new Error("\u5F53\u524D\u6A21\u578B\u5C1A\u672A\u7F13\u5B58\uFF0C\u8BF7\u5148\u4E0B\u8F7D\u5E76\u542F\u7528");
        }
        await queueTranscription(note.id, modelId, "manual");
        return {};
      });
    }
    case "ENABLE_WHISPER":
      return enableWhisper(message.modelId);
    case "SELECT_WHISPER_MODEL":
      return selectWhisperModel(message.modelId);
    case "CHECK_BUNDLED_MODEL":
      return sendToOffscreen({ type: "CHECK_BUNDLED_MODEL" });
    case "GET_WHISPER_STATUS":
      await whisperRecoveryPromise;
      {
        const [settings, processing, cacheStatus] = await Promise.all([
          chrome.storage.local.get([
            "whisperState",
            "whisperError",
            "whisperSelectedModel",
            "whisperDownloadModel",
            "whisperDownloadedBytes"
          ]),
          sendToOffscreen({ type: "GET_PROCESSING_STATE" }),
          sendToOffscreen({ type: "GET_MODEL_CACHE_STATUS" })
        ]);
        const whisperSelectedModel = getWhisperModel(
          settings.whisperSelectedModel || DEFAULT_WHISPER_MODEL_ID
        ).id;
        return {
          whisperState: settings.whisperState,
          whisperError: settings.whisperError,
          selectedModelId: whisperSelectedModel,
          loadedModelId: processing.loadedModelId,
          cachedModelIds: cacheStatus.cachedModelIds,
          download: processing.downloading ? {
            modelId: settings.whisperDownloadModel,
            downloadedBytes: settings.whisperDownloadedBytes
          } : null,
          models: WHISPER_MODELS.map(({ id, label, size, recommended, experimental }) => ({
            id,
            label,
            size,
            recommended: Boolean(recommended),
            experimental: Boolean(experimental)
          }))
        };
      }
    case "SET_SHORTCUT":
      await chrome.storage.local.set({ shortcutCode: message.code });
      return { code: message.code };
    case "EXPORT_SESSION":
      return sendToOffscreen({ type: "EXPORT_SESSION", sessionId: message.sessionId });
    case "CONTEXT_CHANGED": {
      const tab = contextChangedSenderTab(sender);
      if (!tab) {
        console.warn("\u89C6\u9891\u4E0A\u4E0B\u6587\u53D8\u5316\u7F3A\u5C11\u6709\u6548\u53D1\u9001\u6807\u7B7E\u9875");
        return {};
      }
      await configureSidePanelForTab(tab);
      notifyActiveContextChanged(tab.id, tab.windowId);
      return {};
    }
    default:
      return void 0;
  }
}
function assertOffscreenSender(sender) {
  if (sender.url !== chrome.runtime.getURL("offscreen.html")) {
    throw new Error("\u9690\u85CF\u9875\u6D88\u606F\u6765\u6E90\u65E0\u6548");
  }
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.target === "offscreen") return false;
  void handleMessage(message, sender).then(
    (result) => sendResponse({ ok: true, ...result }),
    (error) => sendResponse({ ok: false, error: error.message })
  );
  return true;
});
