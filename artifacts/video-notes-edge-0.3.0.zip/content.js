// src/core/playback-lease.js
function acquirePlaybackLease(media, { now = Date.now(), ttlMs = 9e4, wasPlaying = !media.paused } = {}) {
  return {
    wasPlaying,
    pluginPaused: wasPlaying,
    userIntervened: false,
    acquiredAt: now,
    expiresAt: now + ttlMs,
    shouldPause: wasPlaying && !media.paused
  };
}
function markPlaybackIntervention(lease, action, now = Date.now()) {
  if (!lease) return null;
  return {
    ...lease,
    userIntervened: true,
    intervention: action,
    interventionAt: now
  };
}
function releasePlaybackLease(lease, media, now = Date.now()) {
  if (!lease) return { shouldPlay: false, reason: "missing" };
  if (now > lease.expiresAt) return { shouldPlay: false, reason: "expired" };
  if (lease.userIntervened) return { shouldPlay: false, reason: "user-intervened" };
  if (!lease.wasPlaying || !lease.pluginPaused) {
    return { shouldPlay: false, reason: "not-owned" };
  }
  if (!media.paused) return { shouldPlay: false, reason: "already-playing" };
  return { shouldPlay: true, reason: "owned" };
}

// src/core/push-to-talk.js
var EDITABLE_TAGS = /* @__PURE__ */ new Set(["INPUT", "TEXTAREA", "SELECT"]);
function isEditableTarget(target) {
  if (!target) return false;
  const tagName = String(target.tagName ?? "").toUpperCase();
  return EDITABLE_TAGS.has(tagName) || target.isContentEditable === true || target.getAttribute?.("role") === "textbox";
}
var PushToTalkController = class {
  constructor({
    keyCode = "AltRight",
    maxDurationMs = 6e4,
    onStart,
    onStop
  }) {
    this.keyCode = keyCode;
    this.maxDurationMs = maxDurationMs;
    this.onStart = onStart;
    this.onStop = onStop;
    this.isActive = false;
    this.isStarting = false;
    this.pendingStopReason = null;
    this.timeoutId = null;
  }
  async keyDown(event) {
    if (event.code !== this.keyCode || event.repeat || this.isActive || this.isStarting || isEditableTarget(event.target)) {
      return false;
    }
    this.isStarting = true;
    try {
      await this.onStart();
      this.isActive = true;
      this.timeoutId = setTimeout(() => this.forceStop("timeout"), this.maxDurationMs);
    } catch (error) {
      this.pendingStopReason = null;
      throw error;
    } finally {
      this.isStarting = false;
    }
    if (this.pendingStopReason) {
      const reason = this.pendingStopReason;
      this.pendingStopReason = null;
      await this.forceStop(reason);
    }
    return true;
  }
  async keyUp(event) {
    if (event.code !== this.keyCode) return false;
    if (this.isStarting) {
      this.pendingStopReason = "keyup";
      return true;
    }
    return this.forceStop("keyup");
  }
  async forceStop(reason) {
    if (this.isStarting) {
      this.pendingStopReason = reason;
      return true;
    }
    if (!this.isActive) return false;
    this.isActive = false;
    clearTimeout(this.timeoutId);
    this.timeoutId = null;
    await this.onStop(reason);
    return true;
  }
  reset() {
    const wasActive = this.isActive || this.isStarting;
    this.isActive = false;
    this.isStarting = false;
    this.pendingStopReason = null;
    clearTimeout(this.timeoutId);
    this.timeoutId = null;
    return wasActive;
  }
};

// src/core/site-adapter.js
var YOUTUBE_HOSTS = /* @__PURE__ */ new Set(["youtube.com", "www.youtube.com", "m.youtube.com"]);
var BILIBILI_HOSTS = /* @__PURE__ */ new Set(["bilibili.com", "www.bilibili.com"]);
function positiveInteger(value, fallback = 1) {
  const number = Number.parseInt(value ?? "", 10);
  return Number.isInteger(number) && number > 0 ? number : fallback;
}
function parseVideoContext(url, title = "\u672A\u547D\u540D\u89C6\u9891") {
  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    return null;
  }
  if (YOUTUBE_HOSTS.has(parsed.hostname) && parsed.pathname === "/watch") {
    const videoId = parsed.searchParams.get("v")?.trim();
    if (!videoId) return null;
    return {
      platform: "youtube",
      sessionId: `youtube:${videoId}`,
      videoId,
      part: 1,
      title,
      canonicalUrl: `https://www.youtube.com/watch?v=${encodeURIComponent(videoId)}`
    };
  }
  if (BILIBILI_HOSTS.has(parsed.hostname)) {
    const match = parsed.pathname.match(/^\/video\/(BV[0-9A-Za-z]+)/i);
    if (!match) return null;
    const videoId = match[1];
    const part = positiveInteger(parsed.searchParams.get("p"));
    return {
      platform: "bilibili",
      sessionId: `bilibili:${videoId}:${part}`,
      videoId,
      part,
      title,
      canonicalUrl: `https://www.bilibili.com/video/${videoId}?p=${part}`
    };
  }
  return null;
}
function buildJumpUrl(context, seconds) {
  const time = Math.max(0, Math.floor(Number(seconds) || 0));
  if (context.platform === "youtube") {
    return `https://www.youtube.com/watch?v=${encodeURIComponent(context.videoId)}&t=${time}s`;
  }
  if (context.platform === "bilibili") {
    return `https://www.bilibili.com/video/${context.videoId}?p=${context.part}&t=${time}`;
  }
  throw new Error(`\u4E0D\u652F\u6301\u7684\u5E73\u53F0\uFF1A${context.platform}`);
}

// src/core/subtitle-buffer.js
function normalizeText(text) {
  return String(text ?? "").split(/\r\n?|\n/).map((line) => line.replace(/\s+/g, " ").trim()).filter(Boolean).join("\n");
}
var SubtitleBuffer = class {
  constructor({ retentionSeconds = 60 } = {}) {
    this.retentionSeconds = retentionSeconds;
    this.items = [];
  }
  add(seconds, text) {
    const at = Number(seconds);
    const normalized = normalizeText(text);
    if (!Number.isFinite(at) || !normalized) return;
    const last = this.items.at(-1);
    if (!last || last.text !== normalized) {
      this.items.push({ seconds: at, text: normalized });
    }
    const cutoff = at - this.retentionSeconds;
    this.items = this.items.filter((item) => item.seconds >= cutoff);
  }
  clear() {
    this.items = [];
  }
  before(markerSeconds, { seconds = 20, maxChars = 500 } = {}) {
    const end = Number(markerSeconds);
    if (!Number.isFinite(end) || maxChars <= 0) return "";
    const eligible = this.items.filter(
      (item) => item.seconds <= end && item.seconds >= end - seconds
    );
    const selected = [];
    let length = 0;
    for (let index = eligible.length - 1; index >= 0; index -= 1) {
      const text = eligible[index].text;
      const separatorLength = selected.length === 0 ? 0 : 1;
      const remaining = maxChars - length - separatorLength;
      if (remaining <= 0) break;
      if (text.length > remaining) {
        if (selected.length === 0) selected.unshift(text.slice(-remaining));
        break;
      }
      selected.unshift(text);
      length += text.length + separatorLength;
    }
    return selected.join("\n");
  }
};

// src/core/subtitle-capture.js
var SUBTITLE_WINDOW_OPTIONS = Object.freeze([5, 10, 20, 30]);
function normalizeSubtitleSettings(values = {}) {
  const windowSeconds = Number.isInteger(values.subtitleWindowSeconds) && SUBTITLE_WINDOW_OPTIONS.includes(values.subtitleWindowSeconds) ? values.subtitleWindowSeconds : 20;
  return {
    enabled: typeof values.subtitleEnabled === "boolean" ? values.subtitleEnabled : true,
    windowSeconds
  };
}
var SubtitleCapture = class {
  constructor(values = {}) {
    const settings = normalizeSubtitleSettings(values);
    this.enabled = settings.enabled;
    this.windowSeconds = settings.windowSeconds;
    this.buffer = new SubtitleBuffer({ retentionSeconds: 60 });
  }
  updateSettings(values = {}) {
    const settings = normalizeSubtitleSettings({
      subtitleEnabled: Object.hasOwn(values, "subtitleEnabled") ? values.subtitleEnabled : this.enabled,
      subtitleWindowSeconds: Object.hasOwn(values, "subtitleWindowSeconds") ? values.subtitleWindowSeconds : this.windowSeconds
    });
    if (this.enabled && !settings.enabled) this.buffer.clear();
    this.enabled = settings.enabled;
    this.windowSeconds = settings.windowSeconds;
  }
  add(seconds, text) {
    if (this.enabled) this.buffer.add(seconds, text);
  }
  before(markerSeconds) {
    return this.enabled ? this.buffer.before(markerSeconds, {
      seconds: this.windowSeconds,
      maxChars: 500
    }) : "";
  }
  clear() {
    this.buffer.clear();
  }
};

// src/core/subtitle-text.js
var IMMERSIVE_CONTAINER_SELECTOR = ".imt-captions-text";
var IMMERSIVE_CUE_SELECTOR = ".source-cue, .target-cue";
var NATIVE_SELECTORS = {
  youtube: ".ytp-caption-segment",
  bilibili: ".bpx-player-subtitle-panel-text, .bilibili-player-video-subtitle"
};
function isVisible(element) {
  return element.getClientRects().length > 0;
}
function visibleText(elements, separator) {
  const text = [];
  for (const element of elements) {
    const value = isVisible(element) ? element.textContent?.trim() : "";
    if (value && value !== text.at(-1)) text.push(value);
  }
  return text.join(separator);
}
function readRenderedSubtitleText(root, platform) {
  const immersiveText = visibleText(
    [...root.querySelectorAll(IMMERSIVE_CONTAINER_SELECTOR)].filter(isVisible).flatMap((container) => [...container.querySelectorAll(IMMERSIVE_CUE_SELECTOR)]),
    "\n"
  );
  if (immersiveText) return immersiveText;
  return visibleText(root.querySelectorAll(NATIVE_SELECTORS[platform] ?? ""), " ");
}

// src/content.js
var subtitleCapture = new SubtitleCapture({ subtitleEnabled: false });
var currentMedia = null;
var activeLease = null;
var activeLeaseTimer = null;
var expectedPlaybackEvent = null;
var currentUrl = location.href;
var recordingOverlay = null;
var shortcutError = null;
var shortcutErrorTimer = null;
var shortcutCode = "AltRight";
function videoTitle(platform) {
  if (platform === "youtube") {
    return document.querySelector("h1.ytd-watch-metadata yt-formatted-string")?.textContent?.trim() || document.title.replace(/\s+-\s+YouTube$/, "");
  }
  return document.querySelector("h1.video-title")?.getAttribute("title") || document.querySelector("h1.video-title")?.textContent?.trim() || document.title.replace(/_哔哩哔哩_bilibili$/, "");
}
function getContext() {
  const preliminary = parseVideoContext(location.href);
  if (!preliminary) return null;
  return parseVideoContext(location.href, videoTitle(preliminary.platform));
}
function visibleArea(element) {
  const rect = element.getBoundingClientRect();
  return Math.max(0, Math.min(innerWidth, rect.right) - Math.max(0, rect.left)) * Math.max(0, Math.min(innerHeight, rect.bottom) - Math.max(0, rect.top));
}
function findMedia() {
  const candidates = [...document.querySelectorAll("video")];
  return candidates.sort((left, right) => visibleArea(right) - visibleArea(left))[0] ?? null;
}
function findPlayerElement(context, media) {
  if (context.platform === "youtube") {
    return document.querySelector("#movie_player") ?? media;
  }
  return document.querySelector(".bpx-player-container") ?? document.querySelector(".bilibili-player-video-wrap") ?? media;
}
function consumeExpectedEvent(type) {
  if (expectedPlaybackEvent?.type === type && performance.now() <= expectedPlaybackEvent.expiresAt) {
    expectedPlaybackEvent = null;
    return true;
  }
  expectedPlaybackEvent = null;
  return false;
}
function onMediaStateChange(event) {
  if (!activeLease || consumeExpectedEvent(event.type)) return;
  activeLease = markPlaybackIntervention(activeLease, event.type);
}
function bindMedia() {
  const next = findMedia();
  if (next === currentMedia) return next;
  currentMedia?.removeEventListener("play", onMediaStateChange);
  currentMedia?.removeEventListener("pause", onMediaStateChange);
  currentMedia = next;
  currentMedia?.addEventListener("play", onMediaStateChange);
  currentMedia?.addEventListener("pause", onMediaStateChange);
  return next;
}
function activateMarker(markerId, wasPlaying) {
  if (activeLease) throw new Error("\u5F53\u524D\u5DF2\u6709\u6807\u8BB0\u6B63\u5728\u7F16\u8F91");
  const media = bindMedia();
  if (!media) throw new Error("\u6CA1\u6709\u627E\u5230\u53EF\u7528\u7684\u89C6\u9891\u64AD\u653E\u5668");
  const lease = acquirePlaybackLease(media, { wasPlaying });
  activeLease = { ...lease, markerId };
  activeLeaseTimer = setTimeout(() => void releaseMarker(markerId), 9e4);
  if (lease.shouldPause) {
    expectedPlaybackEvent = { type: "pause", expiresAt: performance.now() + 1500 };
    media.pause();
  }
  return lease.wasPlaying;
}
function markerResumeEligibility(markerId) {
  if (!activeLease || activeLease.markerId !== markerId) return false;
  const media = bindMedia();
  return releasePlaybackLease(activeLease, media ?? { paused: true }).shouldPlay;
}
async function releaseMarker(markerId, { allowResume = true } = {}) {
  if (!activeLease || activeLease.markerId !== markerId) return false;
  clearTimeout(activeLeaseTimer);
  activeLeaseTimer = null;
  const media = bindMedia();
  const result = releasePlaybackLease(activeLease, media ?? { paused: true });
  activeLease = null;
  if (allowResume && result.shouldPlay && media) {
    expectedPlaybackEvent = { type: "play", expiresAt: performance.now() + 1500 };
    try {
      await media.play();
    } catch {
      return false;
    }
  }
  return allowResume && result.shouldPlay;
}
function collectSubtitles() {
  const context = getContext();
  const media = bindMedia();
  if (!context || !media) return;
  subtitleCapture.add(
    media.currentTime,
    readRenderedSubtitleText(document, context.platform)
  );
}
function markerSnapshot(markerId, { deferPause = false } = {}) {
  const context = getContext();
  const media = bindMedia();
  if (!context || !media) throw new Error("\u5F53\u524D\u6807\u7B7E\u9875\u6CA1\u6709\u53D7\u652F\u6301\u7684\u89C6\u9891");
  const seconds = Math.max(0, media.currentTime || 0);
  const rect = findPlayerElement(context, media).getBoundingClientRect();
  const snapshot = {
    context,
    seconds,
    jumpUrl: buildJumpUrl(context, seconds),
    subtitleContext: subtitleCapture.before(seconds),
    rect: {
      x: rect.left,
      y: rect.top,
      width: rect.width,
      height: rect.height
    },
    viewport: { width: innerWidth, height: innerHeight }
  };
  snapshot.wasPlaying = !media.paused;
  if (!deferPause) activateMarker(markerId, snapshot.wasPlaying);
  return snapshot;
}
function showRecordingOverlay() {
  if (!document.fullscreenElement || recordingOverlay) return;
  recordingOverlay = document.createElement("div");
  recordingOverlay.textContent = "\u25CF \u5F55\u97F3\u4E2D";
  Object.assign(recordingOverlay.style, {
    position: "fixed",
    top: "18px",
    left: "50%",
    zIndex: "2147483647",
    transform: "translateX(-50%)",
    padding: "7px 12px",
    borderRadius: "999px",
    color: "#fff",
    background: "rgba(157, 39, 32, .88)",
    font: "600 13px -apple-system, BlinkMacSystemFont, sans-serif",
    pointerEvents: "none"
  });
  (document.fullscreenElement ?? document.documentElement).append(recordingOverlay);
}
function hideRecordingOverlay() {
  recordingOverlay?.remove();
  recordingOverlay = null;
}
function hideShortcutError() {
  clearTimeout(shortcutErrorTimer);
  shortcutError?.remove();
  shortcutError = null;
}
function showShortcutError(message) {
  hideShortcutError();
  shortcutError = document.createElement("div");
  shortcutError.setAttribute("role", "status");
  shortcutError.textContent = `\u89C6\u9891\u7B14\u8BB0\uFF1A${message}`;
  Object.assign(shortcutError.style, {
    position: "fixed",
    right: "18px",
    bottom: "18px",
    zIndex: "2147483647",
    maxWidth: "360px",
    padding: "10px 13px",
    borderRadius: "10px",
    color: "#fff",
    background: "rgba(36, 42, 39, .94)",
    boxShadow: "0 8px 28px rgba(0, 0, 0, .24)",
    font: "500 13px/1.45 -apple-system, BlinkMacSystemFont, sans-serif",
    pointerEvents: "none"
  });
  (document.fullscreenElement ?? document.documentElement).append(shortcutError);
  shortcutErrorTimer = setTimeout(hideShortcutError, 4200);
}
var pushToTalk = new PushToTalkController({
  keyCode: shortcutCode,
  onStart: async () => {
    hideShortcutError();
    const response = await chrome.runtime.sendMessage({ type: "VOICE_START_REQUEST" });
    if (!response?.ok) throw new Error(response?.error ?? "\u5F55\u97F3\u542F\u52A8\u5931\u8D25");
    if (response.canceled) throw new Error("\u5F55\u97F3\u5DF2\u53D6\u6D88");
    showRecordingOverlay();
  },
  onStop: async (reason) => {
    hideRecordingOverlay();
    const response = await chrome.runtime.sendMessage({ type: "VOICE_STOP_REQUEST", reason });
    if (!response?.ok) console.warn("\u89C6\u9891\u7B14\u8BB0\u505C\u6B62\u5F55\u97F3\u5931\u8D25", response?.error);
  }
});
function matchesShortcut(event) {
  return event.code === shortcutCode && !isEditableTarget(event.target);
}
window.addEventListener("keydown", (event) => {
  if (!matchesShortcut(event) || event.repeat) return;
  event.preventDefault();
  void pushToTalk.keyDown(event).catch((error) => {
    hideRecordingOverlay();
    showShortcutError(error.message);
    console.warn("\u89C6\u9891\u7B14\u8BB0\u5F55\u97F3\u542F\u52A8\u5931\u8D25", error);
  });
}, true);
window.addEventListener("keyup", (event) => {
  if (event.code !== shortcutCode) return;
  event.preventDefault();
  void pushToTalk.keyUp(event);
}, true);
window.addEventListener("blur", () => void pushToTalk.forceStop("window-blur"));
window.addEventListener("pagehide", () => void pushToTalk.forceStop("pagehide"));
document.addEventListener("visibilitychange", () => {
  if (document.hidden) void pushToTalk.forceStop("tab-hidden");
});
chrome.storage.local.get({
  shortcutCode: "AltRight",
  subtitleEnabled: true,
  subtitleWindowSeconds: 20
}).then(({
  shortcutCode: saved,
  subtitleEnabled,
  subtitleWindowSeconds
}) => {
  shortcutCode = saved;
  pushToTalk.keyCode = saved;
  subtitleCapture.updateSettings({ subtitleEnabled, subtitleWindowSeconds });
});
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== "local") return;
  if (changes.shortcutCode?.newValue) {
    shortcutCode = changes.shortcutCode.newValue;
    pushToTalk.keyCode = shortcutCode;
  }
  const subtitleSettings = {};
  if (changes.subtitleEnabled) {
    subtitleSettings.subtitleEnabled = changes.subtitleEnabled.newValue;
  }
  if (changes.subtitleWindowSeconds) {
    subtitleSettings.subtitleWindowSeconds = changes.subtitleWindowSeconds.newValue;
  }
  if (Object.keys(subtitleSettings).length > 0) {
    subtitleCapture.updateSettings(subtitleSettings);
  }
});
chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (![
    "GET_PAGE_CONTEXT",
    "PREPARE_MARKER",
    "ACTIVATE_MARKER",
    "GET_MARKER_RESUME_ELIGIBILITY",
    "RELEASE_MARKER",
    "FORCE_STOP_RECORDING"
  ].includes(message.type)) {
    return false;
  }
  const handle = async () => {
    switch (message.type) {
      case "GET_PAGE_CONTEXT":
        return { context: getContext() };
      case "PREPARE_MARKER":
        return markerSnapshot(message.markerId, { deferPause: message.deferPause === true });
      case "ACTIVATE_MARKER":
        return { wasPlaying: activateMarker(message.markerId, message.wasPlaying === true) };
      case "GET_MARKER_RESUME_ELIGIBILITY":
        return { shouldResume: markerResumeEligibility(message.markerId) };
      case "RELEASE_MARKER":
        return {
          resumed: await releaseMarker(message.markerId, {
            allowResume: message.allowResume !== false
          })
        };
      case "FORCE_STOP_RECORDING":
        hideRecordingOverlay();
        return { stopped: pushToTalk.reset() };
      default:
        return {};
    }
  };
  void handle().then(
    (result) => sendResponse({ ok: true, ...result }),
    (error) => sendResponse({ ok: false, error: error.message })
  );
  return true;
});
setInterval(() => {
  collectSubtitles();
  if (location.href !== currentUrl) {
    currentUrl = location.href;
    if (activeLease) void releaseMarker(activeLease.markerId);
    subtitleCapture.clear();
    chrome.runtime.sendMessage({ type: "CONTEXT_CHANGED", context: getContext() });
  }
}, 400);
collectSubtitles();
